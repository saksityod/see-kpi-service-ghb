<?php

namespace App\Http\Controllers;


use DB;
use Validator;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;

class JobLogController extends Controller
{

	public function __construct()
	{
	   $this->middleware('jwt.auth');
	}
	
	public function job_list(Request $request)
	{
		if ($request->database  == 'DQS_STAGING') {
			$items = DB::select("
				select distinct job_name
				from dqs_staging.dbo.stg_job_log			
				order by job_name asc
			");
		} else {
			$items = DB::select("
				select distinct job_name
				from dqs_central.dbo.dqs_job_log			
				order by job_name asc
			");		
		}
		return response()->json($items);
	}
	
	public function index(Request $request)
	{
		if ($request->database == 'DQS_STAGING') {
			$schema_ref = 1;
		} else {
			$schema_ref = 2;
		}
	
		$items = DB::select("
			select *
			from
			(
			  select 1 schema_ref, job_name, job_begin_datetime, job_finish_datetime, data_start_date, data_end_date,
			  iif(cast(sysdatetime() as date) < cast(data_start_date as date),1,0) mark_flag
			  from dqs_staging.dbo.stg_job_log
			  union all
			  select 2 schema_ref, job_name, job_begin_datetime, job_finish_datetime, data_start_date, data_end_date,
			  1 mark_flag
			  from dqs_central.dbo.dqs_job_log
			) a			
			where job_name like ?
			and schema_ref = ?
			order by job_name asc
		", array('%'.$request->job_name.'%', $schema_ref));
		return response()->json($items);
	}
	
	public function update(Request $request)
	{
		if (!empty($request->jobs)) {
			foreach($request->jobs as $j) {
				if ($j['schema_ref'] == 1) {
					DB::statement("
						UPDATE dqs_staging.dbo.stg_job_log 
						SET data_start_date = '{$j['data_start_date']}',
						data_end_date = '{$j['data_end_date']}'
						where job_name = '{$j['job_name']}'
					");
				} else {
					DB::statement("
						UPDATE dqs_central.dbo.dqs_job_log 
						SET data_start_date = '{$j['data_start_date']}',
						data_end_date = '{$j['data_end_date']}'
						where job_name = '{$j['job_name']}'
					");			
				}
			}
		}
		return response()->json(['status' => 200]);
	}
	

	

}