<?php

namespace App\Http\Controllers;

use App\Document;

use StdClass;
use DB;
use Validator;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;

class DocumentController extends Controller
{

	public function __construct()
	{
		$this->middleware('jwt.auth');
		$this->beforeFilter(function(){
			$batch_process = DB::select("
				select service, start_time, end_time, status
				from dqs_repo.dbo.AL_HISTORY
				where service = 'OC_Process_BJ'
				and status = 'S'			
			");
			$mm = DB::select("
				select maintenance_mode
				from dqs_system_config
				where maintenance_mode = 1
			");
			if (!empty($batch_process) || !empty($mm)) {
				return response()->json(['maintenance' => 1, 'message' => 'DQS is under maintenance. Please try again later.']);
			}
		});	   
	}
	
	public function doc_list()
	{
		$items = DB::select("
			select distinct requite_doc, iif(try_cast(substring(requite_doc, 6, 2) as int) is null, 99, try_cast(substring(requite_doc, 6, 2) as int)) order_no
			from etl_rule_requitement
			where requite_doc is not null
			order by order_no asc
		");
		return response()->json($items);
	}
   
    public function index(Request $request)
    {
		$qinput = [];
		
		$query = "
			select id, requite_doc, attribute1, attribute2, attribute3, attribute4, attribute5
			from etl_rule_requitement
			where 1 = 1
		";
		
		empty($request->requite_doc) ?: ($query .= " and requite_doc = ? " AND $qinput[] = $request->requite_doc);
		if (!empty($request->search)) {
			$query .= "
				and (
					attribute1 like ?
					or attribute2 like ?
					or attribute3 like ?
					or attribute4 like ?
					or attribute5 like ?
				)
			";
			$qinput [] = '%'.$request->search.'%';
			$qinput [] = '%'.$request->search.'%';
			$qinput [] = '%'.$request->search.'%';
			$qinput [] = '%'.$request->search.'%';
			$qinput [] = '%'.$request->search.'%';
		}
		
		$items = DB::select($query . ' order by id asc ', $qinput);

		// Get the current page from the url if it's not set default to 1
		empty($request->page) ? $page = 1 : $page = $request->page;
		
		// Number of items per page
		empty($request->rpp) ? $perPage = 10 : $perPage = $request->rpp;

		// Start displaying items from this number;
		$offSet = ($page * $perPage) - $perPage; // Start displaying items from this number

		// Get only the items you need using array_slice (only get 10 items since that's what you need)
		$itemsForCurrentPage = array_slice($items, $offSet, $perPage, false);

		// Return the paginator with only 10 items but with the count of all items and set the it on the correct page
		$result = new LengthAwarePaginator($itemsForCurrentPage, count($items), $perPage, $page);			


		return response()->json($result);
    }
	
	public function show($id)
	{
		try {
			$item = Document::findOrFail($id);
		} catch (ModelNotFoundException $e) {
			return response()->json(['status' => 404, 'data' => 'Document not found.']);
		}
		return response()->json($item);
	}
	
	public function store(Request $request)
	{
        $validator = Validator::make($request->all(), [
            'requite_doc' => 'max:50',
			'attribute1' => 'max:255',
			'attribute2' => 'max:255',
			'attribute3' => 'max:255',
			'attribute4' => 'max:255',
			'attribute5' => 'max:255'
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 400, 'data' => $validator->errors()]);
        } else {
			empty($request->attribute1) ? $attribute1 = null : $attribute1 = $request->attribute1;
			empty($request->attribute2) ? $attribute2 = null : $attribute2 = $request->attribute2;
			empty($request->attribute3) ? $attribute3 = null : $attribute3 = $request->attribute3;
			empty($request->attribute4) ? $attribute4 = null : $attribute4 = $request->attribute4;
			empty($request->attribute5) ? $attribute5 = null : $attribute5 = $request->attribute5;
			
			$item = new Document;
			$item->requite_doc = $request->requite_doc;
			$item->attribute1 = $attribute1;
			$item->attribute2 = $attribute2;
			$item->attribute3 = $attribute3;
			$item->attribute4 = $attribute4;
			$item->attribute5 = $attribute5;
			$item->save();
		}
		
		return response()->json(['status' => 200, 'data' => $item]);	
	}
	
	
	public function update(Request $request, $id)
	{
		try {
			$item = Document::findOrFail($id);
		} catch (ModelNotFoundException $e) {
			return response()->json(['status' => 404, 'data' => 'Document not found.']);
		}
		
        $validator = Validator::make($request->all(), [
            'requite_doc' => 'max:50',
			'attribute1' => 'max:255',
			'attribute2' => 'max:255',
			'attribute3' => 'max:255',
			'attribute4' => 'max:255',
			'attribute5' => 'max:255'
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 400, 'data' => $validator->errors()]);
        } else {
		
			empty($request->attribute1) ? $attribute1 = null : $attribute1 = $request->attribute1;
			empty($request->attribute2) ? $attribute2 = null : $attribute2 = $request->attribute2;
			empty($request->attribute3) ? $attribute3 = null : $attribute3 = $request->attribute3;
			empty($request->attribute4) ? $attribute4 = null : $attribute4 = $request->attribute4;
			empty($request->attribute5) ? $attribute5 = null : $attribute5 = $request->attribute5;
			
			$item->requite_doc = $request->requite_doc;
			$item->attribute1 = $attribute1;
			$item->attribute2 = $attribute2;
			$item->attribute3 = $attribute3;
			$item->attribute4 = $attribute4;
			$item->attribute5 = $attribute5;
			$item->save();
		}
		
		return response()->json(['status' => 200, 'data' => $item]);
				
	}
	
	public function destroy($id)
	{
		try {
			$item = Document::findOrFail($id);
		} catch (ModelNotFoundException $e) {
			return response()->json(['status' => 404, 'data' => 'DOcument not found.']);
		}	

		try {
			
			$item->delete();
		} catch (QueryException $e) {
			if ($e->errorInfo[1] == 547) {
				return response()->json(['status' => 400, 'data' => 'ไม่สามารถลบข้อมูลได้ เนื่องจากมีการใช้งานอยู่']);
			} else {
				return response()->json($e);
			}
		}
		
		return response()->json(['status' => 200]);
		
	}	
	
}