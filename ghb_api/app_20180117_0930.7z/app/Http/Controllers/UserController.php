<?php

namespace App\Http\Controllers;


use App\User;
use App\DQSUser;
use App\Branch;

use DB;
use Validator;
use Auth;
use Exception;
use Excel;

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;

class UserController extends Controller
{

	public function __construct()
	{
		$this->middleware('jwt.auth');
		$this->beforeFilter(function(){
			$batch_process = DB::select("
				select service, start_time, end_time, status
				from dqs_repo.dbo.AL_HISTORY
				where service = 'OC_Process_BJ'
				and status = 'S'			
			");
			$mm = DB::select("
				select maintenance_mode
				from dqs_system_config
				where maintenance_mode = 1
			");
			if (!empty($batch_process) || !empty($mm)) {
				return response()->json(['maintenance' => 1, 'message' => 'DQS is under maintenance. Please try again later.']);
			}
		});	   
	}

	public function export(Request $request) 
	{
		set_time_limit(0);
		ini_set('memory_limit', '2048M');	
		if (empty($request->search_all)) {
			$query = "select a.personnel_id, a.thai_full_name, a.position_name, d.operation_name, b.[desc] own_cost_center,e.ccdef revised_ccdef, e.[desc] revised_cost_center, f.role_id, f.role_name, a.active_flag, a.created_date, a.terminate_date
			from dqs_user a
			left outer join dqs_branch b
			on a.own_cost_center = b.ccdef
			left outer join dqs_region c
			on b.region = c.region_code
			left outer join dqs_branch_operation d
			on c.operation_id = d.operation_id
			left outer join dqs_branch e
			on a.revised_cost_center = e.ccdef
			left outer join dqs_role f
			on a.role_id = f.role_id
			where 1=1"; 


			$qinput = array();
			
			empty($request->personnel_id) ?: ($query .= " and a.personnel_id = ? " AND $qinput[] = $request->personnel_id);
			empty($request->own_cost_center) ?: ($query .= " and b.[desc] like ? " AND $qinput[] = '%' . $request->own_cost_center . '%');
			empty($request->revised_cost_center) ?: ($query .= " and e.[desc] like ? " AND $qinput[] = '%' . $request->revised_cost_center . '%');
			empty($request->role_id) ?: ($query .= " and f.role_id = ? " AND $qinput[] = $request->role_id);
			//!isset($request->active_flag) ?: ($query .= " and a.active_flag = ? " AND $qinput[] = $request->active_flag);
			if ($request->active_flag == '') {
			} else {
				$query .= " and a.active_flag = ? ";
				$qinput[] = $request->active_flag;
			}
			
			// Get all items you want
			$items = DB::select($query, $qinput);
		} else {
			$q = "%" . $request->search_all . "%";
			$items = DB::select('
				select a.thai_full_name, a.position_name, d.operation_name, b.[desc] own_cost_center,e.ccdef revised_ccdef, e.[desc] revised_cost_center, f.role_id, f.role_name, a.active_flag, a.created_date, a.terminate_date
				from dqs_user a
				left outer join dqs_branch b
				on a.own_cost_center = b.ccdef
				left outer join dqs_region c
				on b.region = c.region_code
				left outer join dqs_branch_operation d
				on c.operation_id = d.operation_id
				left outer join dqs_branch e
				on a.revised_cost_center = e.ccdef
				left outer join dqs_role f
				on a.role_id = f.role_id
				where a.thai_full_name like ?
				or a.position_name like ?
				or d.operation_name like ?
				or b.[desc] like ?
				or e.[desc] like ?
				or f.role_name like ?
			', array($q, $q, $q, $q, $q, $q));		
		}
		
		$filename = "USER_" . date('dm') .  substr(date('Y') + 543,2,2);
		$x = Excel::create($filename, function($excel) use($items, $filename) {

			$excel->sheet($filename, function($sheet) use($items) {
				$sheet->appendRow(array('Personnel ID', 'Personnel Name', 'Position', 'Branch Operation', 'Own Cost Center', 'Revised Cost Center', 'Role', 'Created Date', 'Terminate Date'));
				foreach ($items as $i) {
					$sheet->appendRow(array(
						$i->personnel_id,
						$i->thai_full_name, 
						$i->position_name,
						$i->operation_name,
						$i->own_cost_center, 
						$i->revised_cost_center, 
						$i->role_name, 
						$i->created_date, 
						$i->terminate_date
						));
				}
			});

		})->export('xls');			
	}
	
    public function index(Request $request)
    {
		if (empty($request->search_all)) {
			$query = "select a.personnel_id, concat(a.personnel_id,' ',a.thai_full_name) thai_full_name, a.position_name, d.operation_name, b.[desc] own_cost_center,e.ccdef revised_ccdef, e.[desc] revised_cost_center, f.role_id, f.role_name, a.active_flag
			from dqs_user a
			left outer join dqs_branch b
			on a.own_cost_center = b.ccdef
			left outer join dqs_region c
			on b.region = c.region_code
			left outer join dqs_branch_operation d
			on c.operation_id = d.operation_id
			left outer join (
				select iif(brcd=region,region,ccdef) ccdef, dqs_branch.[desc]
				from dqs_branch			
			) e
			on a.revised_cost_center = e.ccdef
			left outer join dqs_role f
			on a.role_id = f.role_id
			where 1=1"; 


			$qinput = array();
			
			empty($request->personnel_id) ?: ($query .= " and a.personnel_id = ? " AND $qinput[] = $request->personnel_id);
			empty($request->own_cost_center) ?: ($query .= " and b.[desc] like ? " AND $qinput[] = '%' . $request->own_cost_center . '%');
			empty($request->revised_cost_center) ?: ($query .= " and e.[desc] like ? " AND $qinput[] = '%' . $request->revised_cost_center . '%');
			empty($request->role_id) ?: ($query .= " and f.role_id = ? " AND $qinput[] = $request->role_id);
		//	!isset($request->active_flag) ?: ($query .= " and a.active_flag = ? " AND $qinput[] = $request->active_flag);
			if ($request->active_flag == '') {
			} else {
				$query .= " and a.active_flag = ? ";
				$qinput[] = $request->active_flag;
			}
			
			
			// Get all items you want
			$items = DB::select($query, $qinput);
		} else {
			$q = "%" . $request->search_all . "%";
		//	$qflag = $request->search_all;
			$items = DB::select('
				select a.thai_full_name, a.position_name, d.operation_name, b.[desc] own_cost_center,e.ccdef revised_ccdef, e.[desc] revised_cost_center, f.role_id, f.role_name, a.active_flag
				from dqs_user a
				left outer join dqs_branch b
				on a.own_cost_center = b.ccdef
				left outer join dqs_region c
				on b.region = c.region_code
				left outer join dqs_branch_operation d
				on c.operation_id = d.operation_id
				left outer join dqs_branch e
				on a.revised_cost_center = e.ccdef
				left outer join dqs_role f
				on a.role_id = f.role_id
				where a.thai_full_name like ?
				or a.position_name like ?
				or d.operation_name like ?
				or b.[desc] like ?
				or e.[desc] like ?
				or f.role_name like ?
			', array($q, $q, $q, $q, $q, $q));		
		}

		// Get the current page from the url if it's not set default to 1
		empty($request->page) ? $page = 1 : $page = $request->page;
		
		// Number of items per page
		empty($request->rpp) ? $perPage = 10 : $perPage = $request->rpp;

		// Start displaying items from this number;
		$offSet = ($page * $perPage) - $perPage; // Start displaying items from this number

		// Get only the items you need using array_slice (only get 10 items since that's what you need)
		$itemsForCurrentPage = array_slice($items, $offSet, $perPage, false);

		// Return the paginator with only 10 items but with the count of all items and set the it on the correct page
		$result = new LengthAwarePaginator($itemsForCurrentPage, count($items), $perPage, $page);			


		return response()->json($result);
    }
	
	public function update(Request $request)
	{
		$success = array();
		$errors = array();
		if (empty($request->users)) {
			return response()->json(['status' => 200, 'data' => $request->users]);
		}
		else
		{
			foreach ($request->users as $u) {
				$user = DQSUser::find($u["personnel_id"]);
				if (empty($user)) {
				} else {
					// $user->fill($u);
					// $user->updated_by = Auth::user()->personnel_id;
					// $user->save();
					//empty($u["role_id"]) ?: $user->role_id = $u["role_id"];
					
					
					if (!empty($u["revised_cost_center"])) {		
						try {
							$checkcc = DB::select("
								select ccdef
								from dqs_branch	
								where ccdef = ?
								or region = ?							
							",array($u["revised_cost_center"],$u["revised_cost_center"]));
						//	$cccount = $checkcc->count();
							if (empty($checkcc)) {
								$errors[] = ['thai_full_name' => $user->thai_full_name, 'message' => 'Revised Cost Center ' . $u["revised_cost_center"] . ' not found.'];
							} else {				
								empty($u["role_id"]) ? $user->role_id = null : $user->role_id = $u["role_id"];
								empty($u["revised_cost_center"]) ?: $user->revised_cost_center = $u["revised_cost_center"];
								$user->updated_by = Auth::user()->personnel_id;
								$user->save();
								$suser = ['personnel_id' => $user->personnel_id, 'role_id' => $user->role_id, 'revised_cost_center' => $user->revised_cost_center];
								$success[] = $suser;								
							}							
						} catch (QueryException $e) {
							$cccount = 0;
							$errors[] = ['thai_full_name' => $user->thai_full_name, 'message' => 'Revised Cost Center ' . $u["revised_cost_center"] . ' not found.'];							
						}
					} else {
						$errors[] = ['thai_full_name' => $user->thai_full_name, 'message' => 'Revised Cost Center cannot be empty.'];					
					}
				}
			}
			return response()->json(['status' => 200, 'data' => $success, 'errors' => $errors]);
		}
		
	}
	
	public function auto_personnel(Request $request)
	{
		$q = '%' . $request->q . '%';
		$items = DB::select("
			select top 10 personnel_id
			from dqs_user
			where personnel_id like ?
		",array($q));
		return response()->json($items);
	}
	
	public function list_revised_cost_center()
	{
		# remove limit 10 later
		$items = DB::select("
			select distinct ccdef, concat(ccdef,' ',dqs_branch.[desc]) [desc]
			from dqs_branch
			order by ccdef asc
		");
		return response()->json($items);
	}
	
	public function auto_revised_cost_center(Request $request)
	{
		$items = DB::select("
			select distinct top 10 iif(brcd=region,region,ccdef) ccdef, concat(iif(brcd=region,region,ccdef),' ',dqs_branch.[desc]) [desc]
			from dqs_branch			
			where concat(iif(brcd=region,region,ccdef),' ',dqs_branch.[desc]) like ?
			order by ccdef asc
		", array('%'.$request->q.'%'));
		return response()->json($items);
	}	
	
	public function auto_cost_center(Request $request)
	{
		$q = '%' . $request->q . '%';
		$items = DB::select('
			select distinct top 10 iif(brcd=region,region,ccdef) ccdef, dqs_branch.[desc]
			from dqs_branch
			where dqs_branch.[desc] like ?
		', array($q));
		return response()->json($items);
	}
	
	// public function store(Request $request)
	// {
		// $user = new User;
		// $user->user_name = $request->user_name;
		// $user->password = bcrypt($request->password);
		// $user->own_cost_center = 1;
		// $user->revised_cost_center = 1;
		// $user->position = 'Admin';
		// $user->super_flag = 1;
		// $user->active_flag = 1;
		// $user->role_id = 1;
		// $user->save();
		// return response()->json($user);
	// }
	
	
}