<?php

namespace App\Http\Controllers;

use App\BranchOperation;

use DB;
use Validator;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;

class BranchOperationController extends Controller
{

	public function __construct()
	{
		$this->middleware('jwt.auth');
		$this->beforeFilter(function(){
			$batch_process = DB::select("
				select service, start_time, end_time, status
				from dqs_repo.dbo.AL_HISTORY
				where service = 'OC_Process_BJ'
				and status = 'S'			
			");
			$mm = DB::select("
				select maintenance_mode
				from dqs_system_config
				where maintenance_mode = 1
			");
			if (!empty($batch_process) || !empty($mm)) {
				return response()->json(['maintenance' => 1, 'message' => 'DQS is under maintenance. Please try again later.']);
			}
		});	   
	}
	
	public function auto_cost_center(Request $request)
	{
		# remove limit 10 later
		$items = DB::select('
			select top 10 ccdef, dqs_branch.[desc]
			from dqs_branch
			where dqs_branch.[desc] like ?
		', array('%'. $request->q .'%'));
		return response()->json($items);
	}	
   
    public function index()
    {
        $items = DB::select("
			select a.operation_id, a.operation_name, b.ccdef, b.[desc] cost_center
			from dqs_branch_operation a
			left outer join dqs_branch b
			on a.cost_center = b.ccdef
			order by a.operation_name asc
		");
		return response()->json($items);
    }
	
	public function show($operation_id)
	{
		try {
			$item = BranchOperation::findOrFail($operation_id);
		} catch (ModelNotFoundException $e) {
			return response()->json(['status' => 404, 'data' => 'Branch Operation not found.']);
		}
		return response()->json($item);
	}
	
	public function store(Request $request)
	{
        $validator = Validator::make($request->all(), [
            'operation_name' => 'required|unique:dqs_branch_operation|max:255',
			'cost_center' => 'required|numeric|digits_between:1,18'
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 400, 'data' => $validator->errors()]);
        } else {
			$item = new BranchOperation;
			$item->operation_name = $request->operation_name;
			$item->cost_center = $request->cost_center;
			$item->created_by = Auth::user()->personnel_id;
			$item->updated_by = Auth::user()->personnel_id;
			$item->save();
		}
		
		return response()->json(['status' => 200, 'data' => $item]);	
	}
	
	public function update(Request $request, $operation_id)
	{
		try {
			$item = BranchOperation::findOrFail($operation_id);
		} catch (ModelNotFoundException $e) {
			return response()->json(['status' => 404, 'data' => 'Branch Operation not found.']);
		}
		
        $validator = Validator::make($request->all(), [
            'operation_name' => 'required|max:255|unique:dqs_branch_operation,operation_name,' . $operation_id . ',operation_id',
			'cost_center' => 'required|numeric|digits_between:1,18'
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 400, 'data' => $validator->errors()]);
        } else {
			$item->fill($request->all());
			$item->updated_by = Auth::user()->personnel_id;
			$item->save();
		}
		
		return response()->json(['status' => 200, 'data' => $item]);
				
	}
		
	public function destroy($operation_id)
	{	
		try {
			$item = BranchOperation::findOrFail($operation_id);
		} catch (ModelNotFoundException $e) {
			return response()->json(['status' => 404, 'data' => 'Branch Operation not found.']);
		}	

		try {
			$item->delete();
		} catch (QueryException $e) {
			if ($e->errorInfo[1] == 547) {
				return response()->json(['status' => 400, 'data' => 'ไม่สามารถลบข้อมูลได้ เนื่องจากมีการใช้งานอยู่']);
			} else {
				return response()->json($e);
			}
		}
		
		return response()->json(['status' => 200]);		
		
	}
	
	
}