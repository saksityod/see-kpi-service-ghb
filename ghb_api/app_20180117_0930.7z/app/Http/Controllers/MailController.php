<?php
namespace App\Http\Controllers;

use Mail;
use Swift_Transport;
use Swift_Message;
use Swift_Mailer;
use App\Http\Controllers\Controller;

class MailController extends Controller
{
	public function sendemail($emailData)
	{
		/*
			$emailData["from"] = "";
			$emailData["to"] = [];
			$emailData["cc"] = [];
			$emailData["bcc"] = [];
			$emailData["subject"] = "";
			$emailData["msg"] = arr();
			$emailData["views-blade"] = "views blade name";

		*/
      $data_toview = array();
			$data_toview['bodymessage'] = $emailData["msg"];
			$email_sender 	= 'wirun@petz.co.th';
			$email_pass		= '2468Mike13579';

			// Backup your default mailer
			$backup = \Mail::getSwiftMailer();

			try{
						//https://accounts.google.com/DisplayUnlockCaptcha
						// Setup your gmail mailer
						$transport = \Swift_SmtpTransport::newInstance('smtp.gmail.com', 587, 'tls');
						$transport->setUsername($email_sender);
						$transport->setPassword($email_pass);

						// Any other mailer configuration stuff needed...
						$gmail = new Swift_Mailer($transport);

						// Set the mailer as gmail
						\Mail::setSwiftMailer($gmail);

						Mail::send($emailData["views-blade"], $data_toview, function($message) use ($emailData)
						{
							$message->from($emailData["from"], 'DQS System Support');
							$message->to($emailData["to"])
							->cc($emailData["cc"])
							->bcc($emailData["bcc"])
							->subject($emailData["subject"])
							->replyTo($emailData["from"], 'Web Application Operating System');

							echo 'The mail has been sent successfully.';
						});

			}catch(\Swift_TransportException $e){
				$response = $e->getMessage() ;
				echo $response;
			}

			// Restore your original mailer
			Mail::setSwiftMailer($backup);

	}
}
