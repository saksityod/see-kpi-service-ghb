<?php

namespace App\Http\Controllers;

use App\Customer;

use StdClass;
use DB;
use Validator;
use Excel;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;

class CustomerController extends Controller
{

	public function __construct()
	{
		$this->middleware('jwt.auth');
		$this->beforeFilter(function(){
			$batch_process = DB::select("
				select service, start_time, end_time, status
				from dqs_repo.dbo.AL_HISTORY
				where service = 'OC_Process_BJ'
				and status = 'S'			
			");
			$mm = DB::select("
				select maintenance_mode
				from dqs_system_config
				where maintenance_mode = 1
			");
			if (!empty($batch_process) || !empty($mm)) {
				return response()->json(['maintenance' => 1, 'message' => 'DQS is under maintenance. Please try again later.']);
			}
		});	   
	}
   
    public function index(Request $request)
    {
		empty($request->cif_no) ? $cif_no = 0 : $cif_no = $request->cif_no;
		$item = DB::select("
			select *
			from dqs_cust
			where acn = ?
		", array($cif_no));
		
		if (empty($item)) {
			$item = new StdClass;
		} else {
			$item = $item[0];
		}
		
		return response()->json($item);
    }
	
	public function export(Request $request)
	{
		// $item = DB::select("
			// select *
			// from dqs_cust
			// where acn = ?
		// ", array($request->cif_no));
		empty($request->cif_no) ? $cif_no = 0 : $cif_no = $request->cif_no;
		$item = Customer::where("acn",$cif_no)->get();
		
		if ($item->count() == 0) {
			return 'CIF Number not found.';
		}
		
		Excel::create('Customer', function($excel) use($item) {
			$excel->sheet('Customer', function($sheet) use($item) {
				$sheet->fromModel($item);
			});
		})->export('xlsx');	
	}
}