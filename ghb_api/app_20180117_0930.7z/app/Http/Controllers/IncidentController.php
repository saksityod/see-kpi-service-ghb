<?php

namespace App\Http\Controllers;

use App\FileIncident;
use App\JobIncident;

// use phpseclib\Crypt_RSA;
// use phpseclib\Net_SFTP;


use DB;
use Validator;
use Auth;
use Excel;
use SoapClient;
use SoapHeader;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;

class IncidentController extends Controller
{

	public function __construct()
	{
	   $this->middleware('jwt.auth',['except' => ['checkfirstsun','checkothersun','checkdaily','runfix','RecursiveFileCheck']]);
	}

	public function runfix()
	{
		set_time_limit(3000);
		$client = new SoapClient("http://10.20.6.125:8080/DataServices/servlet/webservices?ver=2.1&label=run_batch&wsdlxml");
		$getSession = $client->__soapCall("Logon", array("LogonRequest" => array(
			 "username" => "Administrator",
			 "password" => "Passw0rd",
			 "cms_system" => "DQSPRDDATASERV",
			 "cms_authentication" => "secEnterprise"
		 )));
		$sessionID =  $getSession->SessionID;

		$security = array('SessionID' => $sessionID);

		$header = new SoapHeader('http://www.businessobjects.com/DataServices/ServerX.xsd','session',$security, false);

		$setHeader = $client->__setSoapHeaders($header);
		// $client->OP_TestWeb_BJ();

		$runJob = $client->__soapCall("OC_Process_BJ", array(
			"OC_Process_BJ_GlobalVariables" => array(
				"JobName" => "OP_Process_BJ"
			)
		));
		return response()->json(['bods' => (array)$runJob]);
	}

	public function checkfirstsun()
	{
		$notfound = array();
		$found = array();
		if (date('D') == "Sun") {
			if (date('d') == "01") {
				$items = DB::select("
					select file_id, source_ip, source_file_path, contact_type, private_key_path, ftp_username, file_name_format, file_date_format, file_extension, dateadd(day,cast(b.attribute1 as integer),b.data_start_date) file_date
					from dqs_central.dbo.dqs_file a
					left outer join dqs_staging.dbo.stg_job_log b
					on a.job_name = b.job_name
					where frequency in ('D','W')
					and important_flag = 1
				");
				foreach($items as $i) {
					$fullfile = $i->source_file_path . $i->file_name_format . date($i->file_date_format,strtotime($i->file_date)) . "." . $i->file_extension;
					$filename = $i->file_name_format . date($i->file_date_format,strtotime($i->file_date)) . "." . $i->file_extension;
					$sftp = new \Net_SFTP($i->source_ip);
					$key = new \Crypt_RSA();
					$key->loadKey(file_get_contents($i->private_key_path));
					$sftp->login($i->ftp_username, $key);
					$checkfile = $sftp->nlist($fullfile);

					if (empty($checkfile)) {
						$notfound[] = $fullfile;
						$f = new FileIncident;
						$f->filename = $filename;
						$f->file_id = $i->file_id;
						$f->fixed_flag = 0;
						$f->log_dttm = date('Ymd H:i:s');
						$f->created_by = 'DQS';
						$f->updated_by = 'DQS';
						$f->save();
					} else {
						$found[] = $fullfile;
					}
				}
			} else {
				null;
			}
		} else {
			null;
		}

		$runJob = array();
		if (empty($notfound) && !empty($found)) {
			set_time_limit(3000);
			$client = new SoapClient("http://10.20.6.125:8080/DataServices/servlet/webservices?ver=2.1&label=run_batch&wsdlxml");
			$getSession = $client->__soapCall("Logon", array("LogonRequest" => array(
				 "username" => "Administrator",
				 "password" => "Passw0rd",
				 "cms_system" => "DQSPRDDATASERV",
				 "cms_authentication" => "secEnterprise"
			 )));
			$sessionID =  $getSession->SessionID;

			$security = array('SessionID' => $sessionID);

			$header = new SoapHeader('http://www.businessobjects.com/DataServices/ServerX.xsd','session',$security, false);

			$setHeader = $client->__setSoapHeaders($header);
			// $client->OP_TestWeb_BJ();

			$runJob = $client->__soapCall("OC_Process_BJ", array(
				"OC_Process_BJ_GlobalVariables" => array(
					"JobName" => "OP_Process_BJ"
				)
			));
		}

		return response()->json(['found' => $found, 'notfound' => $notfound, 'bods' => (array)$runJob]);
	}

	public function checkothersun()
	{
		$notfound = array();
		$found = array();
		if (date('D') == "Sun") {
			if (date('d') == "01") {
				null;
			} else {
				$items = DB::select("
					select file_id, source_ip, source_file_path, contact_type, private_key_path, ftp_username, file_name_format, file_date_format, file_extension, dateadd(day,cast(b.attribute1 as integer),b.data_start_date) file_date
					from dqs_central.dbo.dqs_file a
					left outer join dqs_staging.dbo.stg_job_log b
					on a.job_name = b.job_name
					where frequency in ('D','W')
					and important_flag = 1
				");
				foreach($items as $i) {
					$fullfile = $i->source_file_path . $i->file_name_format . date($i->file_date_format,strtotime($i->file_date)) . "." . $i->file_extension;
					$filename = $i->file_name_format . date($i->file_date_format,strtotime($i->file_date)) . "." . $i->file_extension;
					$sftp = new \Net_SFTP($i->source_ip);
					$key = new \Crypt_RSA();
					$key->loadKey(file_get_contents($i->private_key_path));
					$sftp->login($i->ftp_username, $key);
					$checkfile = $sftp->nlist($fullfile);

					if (empty($checkfile)) {
						$notfound[] = $fullfile;
						$f = new FileIncident;
						$f->filename = $filename;
						$f->file_id = $i->file_id;
						$f->fixed_flag = 0;
						$f->log_dttm = date('Ymd H:i:s');
						$f->created_by = 'DQS';
						$f->updated_by = 'DQS';
						$f->save();
					} else {
						$found[] = $fullfile;
					}
				}
			}
		} else {
			null;
		}

		$runJob = array();
		if (empty($notfound) && !empty($found)) {
			set_time_limit(3000);
			$client = new SoapClient("http://10.20.6.125:8080/DataServices/servlet/webservices?ver=2.1&label=run_batch&wsdlxml");
			$getSession = $client->__soapCall("Logon", array("LogonRequest" => array(
				 "username" => "Administrator",
				 "password" => "Passw0rd",
				 "cms_system" => "DQSPRDDATASERV",
				 "cms_authentication" => "secEnterprise"
			 )));
			$sessionID =  $getSession->SessionID;

			$security = array('SessionID' => $sessionID);

			$header = new SoapHeader('http://www.businessobjects.com/DataServices/ServerX.xsd','session',$security, false);

			$setHeader = $client->__setSoapHeaders($header);
			// $client->OP_TestWeb_BJ();

			$runJob = $client->__soapCall("OC_Process_BJ", array(
				"OC_Process_BJ_GlobalVariables" => array(
					"JobName" => "OP_Process_BJ"
				)
			));
		}

		return response()->json(['found' => $found, 'notfound' => $notfound, 'bods' => (array)$runJob]);
	}

	public function checkdaily()
	{
		$notfound = array();
		$found = array();
		if (date('D') == "Sun") {
			if (date('d') == "01") {
				null;
			} else {
				null;
			}
		} else {
			$items = DB::select("
				select file_id, source_ip, source_file_path, contact_type, private_key_path, ftp_username, file_name_format, file_date_format, file_extension, dateadd(day,cast(b.attribute1 as integer),b.data_start_date) file_date
				from dqs_central.dbo.dqs_file a
				left outer join dqs_staging.dbo.stg_job_log b
				on a.job_name = b.job_name
				where frequency in ('D')
				and important_flag = 1
			");
			foreach($items as $i) {
				$fullfile = $i->source_file_path . $i->file_name_format . date($i->file_date_format,strtotime($i->file_date)) . "." . $i->file_extension;
				$filename = $i->file_name_format . date($i->file_date_format,strtotime($i->file_date)) . "." . $i->file_extension;
				$sftp = new \Net_SFTP($i->source_ip);
				$key = new \Crypt_RSA();
				$key->loadKey(file_get_contents($i->private_key_path));
				$sftp->login($i->ftp_username, $key);
				$checkfile = $sftp->nlist($fullfile);

				if (empty($checkfile)) {
					$notfound[] = $fullfile;
					$f = new FileIncident;
					$f->filename = $filename;
					$f->file_id = $i->file_id;
					$f->fixed_flag = 0;
					$f->log_dttm = date('Ymd H:i:s');
					$f->created_by = 'DQS';
					$f->updated_by = 'DQS';
					$f->save();
				} else {
					$found[] = $fullfile;
				}
			}
		}

		$runJob = array();
		if (empty($notfound) && !empty($found)) {
			set_time_limit(3000);
			$client = new SoapClient("http://10.20.6.125:8080/DataServices/servlet/webservices?ver=2.1&label=run_batch&wsdlxml");
			$getSession = $client->__soapCall("Logon", array("LogonRequest" => array(
				 "username" => "Administrator",
				 "password" => "Passw0rd",
				 "cms_system" => "DQSPRDDATASERV",
				 "cms_authentication" => "secEnterprise"
			 )));
			$sessionID =  $getSession->SessionID;

			$security = array('SessionID' => $sessionID);

			$header = new SoapHeader('http://www.businessobjects.com/DataServices/ServerX.xsd','session',$security, false);

			$setHeader = $client->__setSoapHeaders($header);
			// $client->OP_TestWeb_BJ();

			$runJob = $client->__soapCall("OC_Process_BJ", array(
				"OC_Process_BJ_GlobalVariables" => array(
					"JobName" => "OP_Process_BJ"
				)
			));
		}

		return response()->json(['found' => $found, 'notfound' => $notfound, 'bods' => (array)$runJob]);
	}

	public function file_incident(Request $request)
	{
		$items = DB::select("
			select a.id, a.log_dttm, a.file_id, b.contact_type, b.source_file_path, a.filename, a.fixed_flag, a.updated_by, a.updated_dttm
			from dqs_file_incident a
			left outer join dqs_file b
			on a.file_id = b.file_id
			where cast(log_dttm as date) between cast(? as date) and cast(? as date)
		", array($request->log_start, $request->log_end));
		return response()->json($items);
	}

	public function job_incident(Request $request)
	{
		$qinput = array();
		$query = "
			select a.object_key, a.service, a.start_time, a.end_time, b.value error_file_path, c.fixed_flag, c.updated_by, c.updated_dttm
			from dqs_repo.dbo.AL_HISTORY a
			left outer join dqs_repo.dbo.AL_HISTORY_INFO b
			on a.OBJECT_KEY = b.OBJECT_KEY
			left outer join dqs_central.dbo.dqs_job_incident c
			on a.OBJECT_KEY = c.object_key
			where a.status = 'E'
			and b.name = 'ERROR_LOG_INFO'
		";

		empty($request->service) ?: ($query .= " and a.service like ? " AND $qinput[] = '%' . $request->service . '%');
		if (empty($request->start_time) || empty($request->end_time)) {
		} else {
			$query .= " and cast(a.start_time as date) between cast(? as date) and cast(? as date) ";
			$qinput[] = $request->start_time;
			$qinput[] = $request->end_time;
		}

		$qfooter = " order by start_time desc ";

		$items = DB::select($query.$qfooter,$qinput);

		return response()->json($items);
	}

	public function update_job(Request $request)
	{
		if (empty($request->jobs)) {
		} else {
			foreach($request->jobs as $j) {
				$item = JobIncident::firstOrNew(array('object_key' => $j['object_key']));
				if ($item->exists) {
					if ($item->fixed_flag != $j['fixed_flag']) {
						$item->fixed_flag = $j['fixed_flag'];
						$item->updated_by = Auth::user()->personnel_id;
						$item->save();
					}
				} else {
					if ($j['fixed_flag'] == 1) {
						$item->fixed_flag = $j['fixed_flag'];
						$item->updated_by = Auth::user()->personnel_id;
						$item->save();
					}
				}
			}
		}

		return response()->json(['status' => 200]);

	}

	public function update_file(Request $request)
	{
		if (empty($request->file_list)) {

		} else {
			foreach($request->file_list as $f) {

				$item = FileIncident::find($f['id']);
				if (empty($item)){

				} else {
					if ($item->fixed_flag != $f['fixed_flag'] ) {
						$item->fixed_flag = $f['fixed_flag'];
						$item->updated_by = Auth::user()->personnel_id;
						$item->save();
					}
				}
			}
		}


		return response()->json(['status' => 200]);

	}

	public function export(Request $request)
	{
		$qinput = array();
		$query = "
			select a.object_key, a.service, a.start_time, a.end_time, b.value error_file_path, c.fixed_flag, c.updated_by, c.updated_dttm
			from dqs_repo.dbo.AL_HISTORY a
			left outer join dqs_repo.dbo.AL_HISTORY_INFO b
			on a.OBJECT_KEY = b.OBJECT_KEY
			left outer join dqs_central.dbo.dqs_job_incident c
			on a.OBJECT_KEY = c.object_key
			where a.status = 'E'
			and b.name = 'ERROR_LOG_INFO'
		";

		empty($request->service) ?: ($query .= " and a.service like ? " AND $qinput[] = '%' . $request->service . '%');
		if (empty($request->start_time) || empty($request->end_time)) {
		} else {
			$query .= " and cast(a.start_time as date) between cast(? as date) and cast(? as date) ";
			$qinput[] = $request->start_time;
			$qinput[] = $request->end_time;
		}

		$qfooter = " order by start_time desc ";

		$items = DB::select($query.$qfooter,$qinput);
		$filename = "DQS_Job_Incident_" . date('dm') .  substr(date('Y') + 543,2,2) . date('H') . date('i') . date('s');

		$x = Excel::create($filename, function($excel) use($items, $filename) {

			$excel->sheet($filename, function($sheet) use($items) {
				$sheet->appendRow(array('Fixed', 'Service Name', 'Start Time', 'End Time', 'Log Path', 'Updated By', 'Updated Date'));
				foreach ($items as $i) {
					$sheet->appendRow(array(
							$i->fixed_flag,
							$i->service,
							$i->start_time,
							$i->end_time,
							$i->error_file_path,
							$i->updated_by,
							$i->updated_dttm
						));
				}
			});
		})->export('xls');
	}

	/*
	public function testSendEmail(){
	  $mailController = new MailController;
	  $emailData["from"] = "DQSPRD-SYSTEM@gsb.or.th";
	  $emailData["to"] = ["PaweethidaN@gsb.or.th"];
	  $emailData["cc"] = [];
	  $emailData["bcc"] = [];
	  $emailData["subject"] = "[DQS]:(ทดสอบ) แจ้งเตือนการตรวจสอบ Interface File";
	  $emailData["msg"] = array();
	  $emailData["views-blade"] = "emails.test";

	  return $mailController->sendemail($emailData);
	}
	*/

	public function RecursiveFileCheck(){
		// SQL Head Strin //
		$sqlStr = "SELECT * FROM(";

		// Get File Info (daily) //
		$sqlStr = $sqlStr." "."
			SELECT file_id,
				CASE WHEN file_name_format = 'OBADEP'
					THEN (SELECT source_ip FROM dqs_file WHERE file_id = 1)
					ELSE source_ip
				END source_ip,
				source_file_path, contact_type, private_key_path, ftp_username, iif(frequency='D', 'daily', iif(frequency='W', 'Weekly', iif(frequency='M', 'Monthly', 'Undefined'))) frequency,
				important_flag, file_name_format, file_date_format, file_extension, dateadd(day,cast(b.attribute1 as integer),b.data_start_date) file_date
			FROM dqs_central.dbo.dqs_file a
			LEFT OUTER JOIN dqs_staging.dbo.stg_job_log b ON a.job_name = b.job_name
			WHERE frequency = 'D'
		";

		// Get File Info (Weekly) //
		if(date('D') == "Sun"){
			$sqlStr = $sqlStr." "."
				UNION
				SELECT file_id,
					CASE WHEN  file_name_format = 'OBA'
						THEN (SELECT source_ip FROM dqs_file WHERE file_id = 2)
						ELSE source_ip
					END source_ip,
					source_file_path, contact_type, private_key_path, ftp_username, iif(frequency='D', 'Daily', iif(frequency='W', 'Weekly', iif(frequency='M', 'Monthly', 'Undefined'))) frequency,
					important_flag, file_name_format, file_date_format, file_extension, dateadd(day,cast(b.attribute1 as integer),b.data_start_date) file_date
				FROM dqs_central.dbo.dqs_file a
				LEFT OUTER JOIN dqs_staging.dbo.stg_job_log b ON a.job_name = b.job_name
				WHERE frequency = 'W'
			";
		}

		// Get File Info (Monthly) //
		if(date('d') == "01"){
			$sqlStr = $sqlStr." "."
				UNION
				SELECT file_id, source_ip, source_file_path, contact_type, private_key_path, ftp_username, iif(frequency='D', 'Daily', iif(frequency='W', 'Weekly', iif(frequency='M', 'Monthly', 'Undefined'))) frequency,
					important_flag, file_name_format, file_date_format, file_extension, dateadd(day,cast(b.attribute1 as integer),b.data_start_date) file_date
				FROM dqs_central.dbo.dqs_file a
				LEFT OUTER JOIN dqs_staging.dbo.stg_job_log b ON a.job_name = b.job_name
				WHERE frequency = 'M'
				AND file_id NOT IN(10, 11)
			";
		}

		// Get File Info (ATM) //
		if(date('d') == '05' || date('d') == '06'){
			$sqlStr = $sqlStr." "."
				UNION
				SELECT file_id, source_ip, source_file_path, contact_type, private_key_path, ftp_username, iif(frequency='D', 'Daily', iif(frequency='W', 'Weekly', iif(frequency='M', 'Monthly', 'Undefined'))) frequency,
					important_flag, file_name_format, file_date_format, file_extension, dateadd(day,cast(b.attribute1 as integer),b.data_start_date) file_date
				FROM dqs_central.dbo.dqs_file a
				LEFT OUTER JOIN dqs_staging.dbo.stg_job_log b ON a.job_name = b.job_name
				WHERE file_id IN(10, 11)
			";
		}

		// SQL Tail String //
		$sqlStr = $sqlStr." ".")mq ORDER BY IIF(important_flag = 1, 1, 99), frequency, file_name_format";
		//return $sqlStr;


	  $responseData = array();
	  $items = DB::select($sqlStr);
	  foreach($items as $i) {
	   $fullfile = $i->source_file_path . $i->file_name_format . date($i->file_date_format,strtotime($i->file_date)) . "." . $i->file_extension;
	   $filename = $i->file_name_format . date($i->file_date_format,strtotime($i->file_date)) . "." . $i->file_extension;
	   $sftp = new \Net_SFTP($i->source_ip);
	   $key = new \Crypt_RSA();
	   $key->loadKey(file_get_contents($i->private_key_path));
	   $sftp->login($i->ftp_username, $key);
	   $checkfile = $sftp->file_exists($fullfile);

	   $dataArr = array();
	   $fileStatus = "";
	   if ($checkfile) {
		$fileStatus = "Found";
	   } else {
		$fileStatus = "Not Found";
	   }
	   array_push($dataArr, $i->contact_type);
	   array_push($dataArr, $filename);
	   array_push($dataArr, $i->frequency);
	   array_push($dataArr, $i->important_flag==1 ? "Yes" : "No");
	   array_push($dataArr, $fileStatus);

	   array_push($responseData, $dataArr);
	  }

	  //return view('emails.html', ['bodymessage' => $responseData]);
	  //return response()->json($responseData);

	  $mailController = new MailController;
	  $emailData["from"] = "DQSPRD-SYSTEM@gsb.or.th";
	  $emailData["to"] = ["Patchareec1@gsb.or.th"];
	  $emailData["cc"] = [];
	  $emailData["bcc"] = [];
	  $emailData["subject"] = "[DQSPRD-SYSTEM]: แจ้งเตือนการตรวจสอบ Interface File";
	  $emailData["msg"] = $responseData;
	  $emailData["views-blade"] = "emails.html";

		return $mailController->sendemail($emailData);
	 }
}
