<?php

namespace App\Http\Controllers;


use DB;
use Validator;
use Auth;
use Excel;
use App\DQSRole;
use App\DQSUser;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;

class OperationReportController extends Controller
{

	public function __construct()
	{
		$this->middleware('jwt.auth');
		$this->beforeFilter(function(){
			$batch_process = DB::select("
				select service, start_time, end_time, status
				from dqs_repo.dbo.AL_HISTORY
				where service = 'OC_Process_BJ'
				and status = 'S'			
			");
			$mm = DB::select("
				select maintenance_mode
				from dqs_system_config
				where maintenance_mode = 1
			");
			if (!empty($batch_process) || !empty($mm)) {
				return response()->json(['maintenance' => 1, 'message' => 'DQS is under maintenance. Please try again later.']);
			}
		});	 	 
	}
	
	public function list_province()
	{
		$items = DB::select("
			select province_code, province_name
			from dqs_province
			order by province_name asc
		");
		return response()->json($items);
	}
	
	public function auto_name(Request $request)
	{
		$items = DB::select("
			select distinct cust_name
			from dqs_merge_cif
			where cust_name like ?
		", array('%' . $request->q . '%'));
		return response()->json($items);
	}
	
	public function auto_surname(Request $request)
	{
		$items = DB::select("
			select distinct cust_surname
			from dqs_merge_cif
			where cust_surname like ?
		", array('%' . $request->q . '%'));
		return response()->json($items);	
	}
	
	public function list_operation()
	{
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		if ($role->all_branch_flag == 1) {
			$items = DB::select("
				select distinct a.operation_id, a.operation_name
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join dqs_branch c
				on b.region_code = c.region		
			");
		} else {
			$checkop = DB::select("
				select operation_id, operation_name
				from dqs_branch_operation
				where cost_center = ?
			", array($user->revised_cost_center));
			
			if (empty($checkop)) {
				$items = DB::select("
					select distinct a.operation_id, a.operation_name
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
						select iif(brcd=region,region,ccdef) ccdef, dqs_branch.[desc], region
						from dqs_branch			
					) c
					on b.region_code = c.region		
					where c.ccdef = ?
				", array($user->revised_cost_center));
			} else {
				$items = $checkop;
			}
		}
		
		return response()->json($items);
	}
	
	public function list_region(Request $request)
	{
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		if ($role->all_branch_flag == 1) {
			$items = DB::select("
				select distinct c.region, c.regdesc
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join dqs_branch c
				on b.region_code = c.region		
				where a.operation_id = ?
				order by c.regdesc asc
			", array($request->operation_id));
		} else {
			$checkop = DB::select("
				select operation_id, operation_name
				from dqs_branch_operation
				where cost_center = ?
			", array($user->revised_cost_center));
			
			if (empty($checkop)) {
				$items = DB::select("
					select distinct c.region, c.regdesc
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					select iif(brcd=region,region,ccdef) ccdef, dqs_branch.[desc], region, regdesc
					from dqs_branch			
					) c
					on b.region_code = c.region	
					where c.ccdef = ?
					order by c.regdesc asc
				", array($user->revised_cost_center));					
			} else {
				$items = DB::select("
					select distinct c.region, c.regdesc
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join dqs_branch c
					on b.region_code = c.region	
					where a.operation_id = ?
					order by c.regdesc asc
				", array($checkop[0]->operation_id));
			}		
		}
		
		return response()->json($items);	
	}
	
	public function list_district(Request $request)
	{
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		if ($role->all_branch_flag == 1) {
			$items = DB::select("
				select distinct c.dist, c.distdesc
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join dqs_branch c
				on b.region_code = c.region		
				where c.region = ?
				order by c.distdesc asc
			", array($request->region));
		} else {
			// $checkregion = DB::select("
				// select region, regdesc
				// from dqs_branch
				// where region = ?
			// ", array($request->revised_cost_center));
			
			// if (empty($checkregion)) {
				// $items = DB::select("
					// select distinct c.dist, c.distdesc
					// from dqs_branch_operation a
					// left outer join dqs_region b
					// on a.operation_id = b.operation_id
					// left outer join dqs_branch c
					// on b.region_code = c.region	
					// where c.ccdef = ?
				// ", array($user->revised_cost_center));				
			// } else {
				// $items = DB::select("
					// select distinct c.dist, c.distdesc
					// from dqs_branch_operation a
					// left outer join dqs_region b
					// on a.operation_id = b.operation_id
					// left outer join dqs_branch c
					// on b.region_code = c.region	
					// where c.region = ?
				// ", array($checkregion[0]->region));			
			// }
			
			$checkop = DB::select("
				select operation_id, operation_name
				from dqs_branch_operation
				where cost_center = ?
			", array($user->revised_cost_center));
			
			if (empty($checkop)) {
				$checkregion = DB::select("
					select region, regdesc
					from dqs_branch
					where region = ?
				", array($user->revised_cost_center));
				
				if (empty($checkregion)) {
					$items = DB::select("
						select distinct dist, distdesc
						from dqs_branch
						where ccdef = ?
						order by distdesc asc
					", array($user->revised_cost_center));
		
				} else {		
					$items = DB::select("
						select distinct c.dist, c.distdesc
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join dqs_branch c
						on b.region_code = c.region	
						where c.region = ?
						order by c.distdesc asc
					",array($request->region));			
				}			
			} else {
				$items = DB::select("
					select distinct c.dist, c.distdesc
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join dqs_branch c
					on b.region_code = c.region	
					where a.cost_center = ?
					and c.region = ?
					order by c.distdesc asc
				",array($user->revised_cost_center, $request->region));	
			}								
				
		}
		
		return response()->json($items);
		
	}
	
	public function list_branch(Request $request)
	{
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		if ($role->all_branch_flag == 1) {
			$items = DB::select("
				select distinct c.brcd, concat(c.brcd,' ',c.[desc]) [desc]
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join dqs_branch c
				on b.region_code = c.region		
				where c.dist = ?
				order by c.brcd asc
			", array($request->dist));
		} else {
			$checkop = DB::select("
				select operation_id, operation_name
				from dqs_branch_operation
				where cost_center = ?
			", array($user->revised_cost_center));
			
			if (empty($checkop)) {
				$checkregion = DB::select("
					select region, regdesc
					from dqs_branch
					where region = ?
				", array($user->revised_cost_center));
				
				if (empty($checkregion)) {
					$checkdist = DB::select("
						select dist, distdesc
						from dqs_branch
						where dist = ?
					", array($user->revised_cost_center));
					
					if (empty($checkdist)) {
						$items = DB::select("
							select distinct c.brcd, concat(c.brcd,' ',c.[desc]) [desc]
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
								select iif(brcd=region,region,ccdef) ccdef, dqs_branch.[desc], region, brcd
								from dqs_branch			
							) c
							on b.region_code = c.region	
							where c.ccdef = ?
							order by c.brcd asc
						",array($user->revised_cost_center));						
					} else {	
						$items = DB::select("
							select distinct c.brcd, concat(c.brcd,' ',c.[desc]) [desc]
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join dqs_branch c
							on b.region_code = c.region	
							where c.dist = ?
							order by c.brcd asc
						",array($request->dist));					
					}				
				} else {		
					$items = DB::select("
						select distinct c.brcd, concat(c.brcd,' ',c.[desc]) [desc]
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join dqs_branch c
						on b.region_code = c.region	
						where c.dist = ?
						order by c.brcd asc
					",array($request->dist));					
				}			
			} else {
				$items = DB::select("
					select distinct c.brcd, concat(c.brcd,' ',c.[desc]) [desc]
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join dqs_branch c
					on b.region_code = c.region	
					where a.cost_center = ?
					and c.dist = ?
					order by c.brcd asc
				",array($user->revised_cost_center, $request->dist));
	
			}				
			
		}
		
		return response()->json($items);
		
	}
	
	public function no_progress(Request $request)
	{
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {
			empty($request->year) ?: ($op_string .= ' and year = ' . $request->year);	
			empty($request->month) ?: ($op_string .= ' and month_no = ' . $request->month);		
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);			
		} else {
			empty($request->year) ?: ($op_string .= ' and year = ' . $request->year);	
			empty($request->month) ?: ($op_string .= ' and month_no = ' . $request->month);				
			$op_string .= "
				and operation_code in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);		
		}

		$operations_query = "
			select operation_code, operation_name, 
			sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
			sum(iif(rule_group = 'Mapping',1,0)) mapping,
			sum(iif(rule_group = 'Matching',1,0)) matching,
			sum(iif(rule_group = 'Edit',1,0)) edit,
			sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
			sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
			count(distinct cif_no) total
			from (
			  select distinct operation_name, operation_code, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
			  from dqs_validate
			  where validate_status in ('incomplete','wrong')
			  and inform_flag = 1
			  {$op_string}
			  union
			  select distinct operation_name, operation_code, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
			  from dqs_initial_validate
			  where validate_status in ('incomplete','wrong')
			  and inform_flag = 1
			  {$op_string}
			) a			
			group by operation_code, operation_name
			order by operation_name asc
		";

		$operations = DB::select($operations_query);
		//return $operations;
		foreach ($operations as $o) {
			
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {
				empty($request->year) ?: ($region_string .= ' and year = ' . $request->year);	
				empty($request->month) ?: ($region_string .= ' and month_no = ' . $request->month);		
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);			
			} else {
				empty($request->year) ?: ($region_string .= ' and year = ' . $request->year);	
				empty($request->month) ?: ($region_string .= ' and month_no = ' . $request->month);	
				$region_string .= "
					and region_code in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);		
			}
			$regions_query = "
				select region_code, region_name, 
				sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
				sum(iif(rule_group = 'Mapping',1,0)) mapping,
				sum(iif(rule_group = 'Matching',1,0)) matching,
				sum(iif(rule_group = 'Edit',1,0)) edit,
				sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
				sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
				count(distinct cif_no) total
				from (
				  select distinct region_code, region_name, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
				  from dqs_validate
				  where validate_status in ('incomplete','wrong')
				  and inform_flag = 1
				  and operation_code = {$o->operation_code}
				  {$region_string}	
				  union
				  select distinct region_code, region_name, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
				  from dqs_initial_validate
				  where validate_status in ('incomplete','wrong')
				  and inform_flag = 1
				  and operation_code = {$o->operation_code}
				  {$region_string}					  
				) a
				group by region_code, region_name	
				order by region_name asc
			";

			$regions = DB::select($regions_query);
			
			foreach ($regions as $r) {
				$district_string = "";
			
				if ($role->all_branch_flag == 1) {
					empty($request->year) ?: ($district_string .= ' and year = ' . $request->year);	
					empty($request->month) ?: ($district_string .= ' and month_no = ' . $request->month);				
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);			
				} else {
					empty($request->year) ?: ($district_string .= ' and year = ' . $request->year);	
					empty($request->month) ?: ($district_string .= ' and month_no = ' . $request->month);	
					$district_string .= "
						and district_code in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);		
				}
				$districts_query = "
					select district_code, district_name, 
					sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
					sum(iif(rule_group = 'Mapping',1,0)) mapping,
					sum(iif(rule_group = 'Matching',1,0)) matching,
					sum(iif(rule_group = 'Edit',1,0)) edit,
					sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
					sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
					count(distinct cif_no) total
					from (
					  select distinct district_code, district_name, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
					  from dqs_validate
					  where validate_status in ('incomplete','wrong')
					  and inform_flag = 1
					  and region_code = {$r->region_code}
					  {$district_string}
					  union
					  select distinct district_code, district_name, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
					  from dqs_initial_validate
					  where validate_status in ('incomplete','wrong')
					  and inform_flag = 1
					  and region_code = {$r->region_code}
					  {$district_string}					  
					) a
					group by district_code, district_name	
					order by district_name asc
				";

				$districts = DB::select($districts_query);
				
				foreach ($districts as $d) {
					$branch_string = "";
				
					if ($role->all_branch_flag == 1) {
						empty($request->year) ?: ($branch_string .= ' and year = ' . $request->year);	
						empty($request->month) ?: ($branch_string .= ' and month_no = ' . $request->month);										
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);			
					} else {
						empty($request->year) ?: ($branch_string .= ' and year = ' . $request->year);	
						empty($request->month) ?: ($branch_string .= ' and month_no = ' . $request->month);							
						$branch_string .= "
							and contact_branch_code in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);	
					}				
					

					$branches_query = "
						select contact_branch_code, contact_branch_name, 
						sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
						sum(iif(rule_group = 'Mapping',1,0)) mapping,
						sum(iif(rule_group = 'Matching',1,0)) matching,
						sum(iif(rule_group = 'Edit',1,0)) edit,
						sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
						sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
						count(distinct cif_no) total
						from (
						  select distinct contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
						  from dqs_validate
						  where validate_status in ('incomplete','wrong')
						  and inform_flag = 1
						  and district_code = {$d->district_code}
						  {$branch_string}
						  union
						  select distinct contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
						  from dqs_initial_validate
						  where validate_status in ('incomplete','wrong')
						  and inform_flag = 1
						  and district_code = {$d->district_code}
						  {$branch_string}						  
						) a
						group by contact_branch_code, contact_branch_name	
						order by contact_branch_name asc
					";

					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}		
		return response()->json($operations);
	}
	
	public function no_progress_export(Request $request)
	{
		set_time_limit(0);
		ini_set('memory_limit', '2048M');	
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {
			empty($request->year) ?: ($op_string .= ' and year = ' . $request->year);	
			empty($request->month) ?: ($op_string .= ' and month_no = ' . $request->month);		
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);			
		} else {
			empty($request->year) ?: ($op_string .= ' and year = ' . $request->year);	
			empty($request->month) ?: ($op_string .= ' and month_no = ' . $request->month);				
			$op_string .= "
				and operation_code in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);		
		}

		$operations_query = "
			select operation_code, operation_name, 
			sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
			sum(iif(rule_group = 'Mapping',1,0)) mapping,
			sum(iif(rule_group = 'Matching',1,0)) matching,
			sum(iif(rule_group = 'Edit',1,0)) edit,
			sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
			sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
			count(distinct cif_no) total
			from (
			  select distinct operation_name, operation_code, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
			  from dqs_validate
			  where validate_status in ('incomplete','wrong')
			  and inform_flag = 1
			  {$op_string}
			  union
			  select distinct operation_name, operation_code, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
			  from dqs_initial_validate
			  where validate_status in ('incomplete','wrong')
			  and inform_flag = 1
			  {$op_string}
			) a			
			group by operation_code, operation_name
			order by operation_name asc
		";

		$operations = DB::select($operations_query);
		//return $operations;
		foreach ($operations as $o) {
			
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {
				empty($request->year) ?: ($region_string .= ' and year = ' . $request->year);	
				empty($request->month) ?: ($region_string .= ' and month_no = ' . $request->month);		
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);			
			} else {
				empty($request->year) ?: ($region_string .= ' and year = ' . $request->year);	
				empty($request->month) ?: ($region_string .= ' and month_no = ' . $request->month);	
				$region_string .= "
					and region_code in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);		
			}
			$regions_query = "
				select region_code, region_name, 
				sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
				sum(iif(rule_group = 'Mapping',1,0)) mapping,
				sum(iif(rule_group = 'Matching',1,0)) matching,
				sum(iif(rule_group = 'Edit',1,0)) edit,
				sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
				sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
				count(distinct cif_no) total
				from (
				  select distinct region_code, region_name, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
				  from dqs_validate
				  where validate_status in ('incomplete','wrong')
				  and inform_flag = 1
				  and operation_code = {$o->operation_code}
				  {$region_string}	
				  union
				  select distinct region_code, region_name, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
				  from dqs_initial_validate
				  where validate_status in ('incomplete','wrong')
				  and inform_flag = 1
				  and operation_code = {$o->operation_code}
				  {$region_string}					  
				) a
				group by region_code, region_name	
				order by region_name asc
			";

			$regions = DB::select($regions_query);
			
			foreach ($regions as $r) {
				$district_string = "";
			
				if ($role->all_branch_flag == 1) {
					empty($request->year) ?: ($district_string .= ' and year = ' . $request->year);	
					empty($request->month) ?: ($district_string .= ' and month_no = ' . $request->month);				
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);			
				} else {
					empty($request->year) ?: ($district_string .= ' and year = ' . $request->year);	
					empty($request->month) ?: ($district_string .= ' and month_no = ' . $request->month);	
					$district_string .= "
						and district_code in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);		
				}
				$districts_query = "
					select district_code, district_name, 
					sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
					sum(iif(rule_group = 'Mapping',1,0)) mapping,
					sum(iif(rule_group = 'Matching',1,0)) matching,
					sum(iif(rule_group = 'Edit',1,0)) edit,
					sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
					sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
					count(distinct cif_no) total
					from (
					  select distinct district_code, district_name, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
					  from dqs_validate
					  where validate_status in ('incomplete','wrong')
					  and inform_flag = 1
					  and region_code = {$r->region_code}
					  {$district_string}
					  union
					  select distinct district_code, district_name, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
					  from dqs_initial_validate
					  where validate_status in ('incomplete','wrong')
					  and inform_flag = 1
					  and region_code = {$r->region_code}
					  {$district_string}					  
					) a
					group by district_code, district_name	
					order by district_name asc
				";

				$districts = DB::select($districts_query);
				
				foreach ($districts as $d) {
					$branch_string = "";
				
					if ($role->all_branch_flag == 1) {
						empty($request->year) ?: ($branch_string .= ' and year = ' . $request->year);	
						empty($request->month) ?: ($branch_string .= ' and month_no = ' . $request->month);										
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);			
					} else {
						empty($request->year) ?: ($branch_string .= ' and year = ' . $request->year);	
						empty($request->month) ?: ($branch_string .= ' and month_no = ' . $request->month);							
						$branch_string .= "
							and contact_branch_code in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);	
					}				
					

					$branches_query = "
						select contact_branch_code, contact_branch_name, 
						sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
						sum(iif(rule_group = 'Mapping',1,0)) mapping,
						sum(iif(rule_group = 'Matching',1,0)) matching,
						sum(iif(rule_group = 'Edit',1,0)) edit,
						sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
						sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
						count(distinct cif_no) total
						from (
						  select distinct contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
						  from dqs_validate
						  where validate_status in ('incomplete','wrong')
						  and inform_flag = 1
						  and district_code = {$d->district_code}
						  {$branch_string}
						  union
						  select distinct contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
						  from dqs_initial_validate
						  where validate_status in ('incomplete','wrong')
						  and inform_flag = 1
						  and district_code = {$d->district_code}
						  {$branch_string}						  
						) a
						group by contact_branch_code, contact_branch_name	
						order by contact_branch_name asc
					";

					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}		
		$filename = "No_Progress_Report_" . date('dm') .  substr(date('Y') + 543,2,2);
		$x = Excel::create($filename, function($excel) use($operations, $filename) {
			$excel->sheet($filename, function($sheet) use($operations) {
				$sheet->appendRow(array('', '', 'Cleansing', 'Mapping', 'Matching', 'Edit', 'KPI-Last Contact', 'KPI-Update', 'Total (Distinct)'));				
				foreach ($operations as $o) {
					$sheet->appendRow(array(
						$o->operation_name,
						'ผลรวม',
						$o->cleansing,
						$o->mapping,
						$o->matching,
						$o->edit,
						$o->kpi,
						$o->kpi_update,
						$o->total
					));
					foreach ($o->regions as $r) {
						$sheet->appendRow(array(
							'--' . $r->region_name,
							'ผลรวม',
							$r->cleansing,
							$r->mapping,
							$r->matching,
							$r->edit,
							$r->kpi,
							$r->kpi_update,
							$r->total
						));					
						foreach ($r->districts as $d) {
							$sheet->appendRow(array(
								'----' . $d->district_name,
								'ผลรวม',
								$d->cleansing,
								$d->mapping,
								$d->matching,
								$d->edit,
								$d->kpi,
								$d->kpi_update,
								$d->total
							));
							$sheet->appendRow(array('------รหัสสาขา', 'ชื่อสาขา'));
							foreach ($d->branches as $b) {
								$sheet->appendRow(array(
									'------' . $b->contact_branch_code,
									$b->contact_branch_name,
									$b->cleansing,
									$b->mapping,
									$b->matching,
									$b->edit,
									$b->kpi,
									$b->kpi_update,
									$b->total
								));									
							}
						}
					}
				}

			});

		})->export('xls');			
		
	}	
	
	public function progressed(Request $request)
	{
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {
			empty($request->month) ?: ($op_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT) . "'") ;				
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);			
		} else {
			empty($request->month) ?: ($op_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT) . "'");	
			$op_string .= "
				and operation_code in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);		
		}
	

		$operations_query = "
			select operation_code, operation_name, 
			sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
			sum(iif(rule_group = 'Mapping',1,0)) mapping,
			sum(iif(rule_group = 'Matching',1,0)) matching,
			sum(iif(rule_group = 'Edit',1,0)) edit,
			sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
			sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
			count(distinct cif_no) total
			from (
			  select distinct operation_name, operation_code, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
			  from dqs_validate
			  where validate_status in ('complete','correct','transfer')
			  and inform_flag = 1
			  {$op_string}
			  union
			  select distinct operation_name, operation_code, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
			  from dqs_initial_validate
			  where validate_status in ('complete','correct','transfer')
			  and inform_flag = 1
			  {$op_string}
			) a			
			group by operation_code, operation_name
			order by operation_name asc
		";

		$operations = DB::select($operations_query);
		//return $operations;
		foreach ($operations as $o) {
			
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {
				empty($request->month) ?: ($region_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");				
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);			
			} else {
				empty($request->month) ?: ($region_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");	
				$region_string .= "
					and region_code in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);		
			}
			$regions_query = "
				select region_code, region_name, 
				sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
				sum(iif(rule_group = 'Mapping',1,0)) mapping,
				sum(iif(rule_group = 'Matching',1,0)) matching,
				sum(iif(rule_group = 'Edit',1,0)) edit,
				sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
				sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
				count(distinct cif_no) total
				from (
				  select distinct region_code, region_name, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
				  from dqs_validate
				  where validate_status in ('complete','correct','transfer')
				  and inform_flag = 1
				  and operation_code = {$o->operation_code}
				  {$region_string}	
				  union
				  select distinct region_code, region_name, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
				  from dqs_initial_validate
				  where validate_status in ('complete','correct','transfer')
				  and inform_flag = 1
				  and operation_code = {$o->operation_code}
				  {$region_string}					  
				) a
				group by region_code, region_name	
				order by region_name asc
			";

			$regions = DB::select($regions_query);
			
			foreach ($regions as $r) {
				$district_string = "";
			
				if ($role->all_branch_flag == 1) {
					empty($request->month) ?: ($district_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");				
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);			
				} else {
					empty($request->month) ?: ($district_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");	
					$district_string .= "
						and district_code in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);		
				}
				$districts_query = "
					select district_code, district_name, 
					sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
					sum(iif(rule_group = 'Mapping',1,0)) mapping,
					sum(iif(rule_group = 'Matching',1,0)) matching,
					sum(iif(rule_group = 'Edit',1,0)) edit,
					sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
					sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
					count(distinct cif_no) total
					from (
					  select distinct district_code, district_name, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
					  from dqs_validate
					  where validate_status in ('complete','correct','transfer')
					  and inform_flag = 1
					  and region_code = {$r->region_code}
					  {$district_string}
					  union
					  select distinct district_code, district_name, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
					  from dqs_initial_validate
					  where validate_status in ('complete','correct','transfer')
					  and inform_flag = 1
					  and region_code = {$r->region_code}
					  {$district_string}					  
					) a
					group by district_code, district_name	
					order by district_name asc
				";

				$districts = DB::select($districts_query);
				
				foreach ($districts as $d) {
					$branch_string = "";
				
					if ($role->all_branch_flag == 1) {
						empty($request->month) ?: ($branch_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");				
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);			
					} else {
						empty($request->month) ?: ($branch_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");	
						$branch_string .= "
							and contact_branch_code in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);	
					}				
					

					$branches_query = "
						select contact_branch_code, contact_branch_name, 
						sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
						sum(iif(rule_group = 'Mapping',1,0)) mapping,
						sum(iif(rule_group = 'Matching',1,0)) matching,
						sum(iif(rule_group = 'Edit',1,0)) edit,
						sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
						sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
						count(distinct cif_no) total
						from (
						  select distinct contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
						  from dqs_validate
						  where validate_status in ('complete','correct','transfer')
						  and inform_flag = 1
						  and district_code = {$d->district_code}
						  {$branch_string}
						  union
						  select distinct contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
						  from dqs_initial_validate
						  where validate_status in ('complete','correct','transfer')
						  and inform_flag = 1
						  and district_code = {$d->district_code}
						  {$branch_string}						  
						) a
						group by contact_branch_code, contact_branch_name	
						order by contact_branch_name asc
					";

					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}		
		return response()->json($operations);
	}
	
	public function progressed_export(Request $request)
	{
		set_time_limit(0);
		ini_set('memory_limit', '2048M');
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {
			empty($request->month) ?: ($op_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT) . "'") ;				
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);			
		} else {
			empty($request->month) ?: ($op_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT) . "'");	
			$op_string .= "
				and operation_code in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);		
		}
	

		$operations_query = "
			select operation_code, operation_name, 
			sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
			sum(iif(rule_group = 'Mapping',1,0)) mapping,
			sum(iif(rule_group = 'Matching',1,0)) matching,
			sum(iif(rule_group = 'Edit',1,0)) edit,
			sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
			sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
			count(distinct cif_no) total
			from (
			  select distinct operation_name, operation_code, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
			  from dqs_validate
			  where validate_status in ('complete','correct','transfer')
			  and inform_flag = 1
			  {$op_string}
			  union
			  select distinct operation_name, operation_code, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
			  from dqs_initial_validate
			  where validate_status in ('complete','correct','transfer')
			  and inform_flag = 1
			  {$op_string}
			) a			
			group by operation_code, operation_name
			order by operation_name asc
		";

		$operations = DB::select($operations_query);
		//return $operations;
		foreach ($operations as $o) {
			
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {
				empty($request->month) ?: ($region_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");				
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);			
			} else {
				empty($request->month) ?: ($region_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");	
				$region_string .= "
					and region_code in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);		
			}
			$regions_query = "
				select region_code, region_name, 
				sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
				sum(iif(rule_group = 'Mapping',1,0)) mapping,
				sum(iif(rule_group = 'Matching',1,0)) matching,
				sum(iif(rule_group = 'Edit',1,0)) edit,
				sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
				sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
				count(distinct cif_no) total
				from (
				  select distinct region_code, region_name, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
				  from dqs_validate
				  where validate_status in ('complete','correct','transfer')
				  and inform_flag = 1
				  and operation_code = {$o->operation_code}
				  {$region_string}	
				  union
				  select distinct region_code, region_name, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
				  from dqs_initial_validate
				  where validate_status in ('complete','correct','transfer')
				  and inform_flag = 1
				  and operation_code = {$o->operation_code}
				  {$region_string}					  
				) a
				group by region_code, region_name	
				order by region_name asc
			";

			$regions = DB::select($regions_query);
			
			foreach ($regions as $r) {
				$district_string = "";
			
				if ($role->all_branch_flag == 1) {
					empty($request->month) ?: ($district_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");				
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);			
				} else {
					empty($request->month) ?: ($district_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");	
					$district_string .= "
						and district_code in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);		
				}
				$districts_query = "
					select district_code, district_name, 
					sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
					sum(iif(rule_group = 'Mapping',1,0)) mapping,
					sum(iif(rule_group = 'Matching',1,0)) matching,
					sum(iif(rule_group = 'Edit',1,0)) edit,
					sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
					sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
					count(distinct cif_no) total
					from (
					  select distinct district_code, district_name, contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
					  from dqs_validate
					  where validate_status in ('complete','correct','transfer')
					  and inform_flag = 1
					  and region_code = {$r->region_code}
					  {$district_string}
					  union
					  select distinct district_code, district_name, contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
					  from dqs_initial_validate
					  where validate_status in ('complete','correct','transfer')
					  and inform_flag = 1
					  and region_code = {$r->region_code}
					  {$district_string}					  
					) a
					group by district_code, district_name	
					order by district_name asc
				";

				$districts = DB::select($districts_query);
				
				foreach ($districts as $d) {
					$branch_string = "";
				
					if ($role->all_branch_flag == 1) {
						empty($request->month) ?: ($branch_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");				
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);			
					} else {
						empty($request->month) ?: ($branch_string .= " and CONVERT(nvarchar(6), rule_end_date, 112) = '". $request->year . str_pad($request->month,2,"0",STR_PAD_LEFT)  . "'");	
						$branch_string .= "
							and contact_branch_code in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);	
					}				
					

					$branches_query = "
						select contact_branch_code, contact_branch_name, 
						sum(iif(rule_group = 'Cleansing',1,0)) cleansing,
						sum(iif(rule_group = 'Mapping',1,0)) mapping,
						sum(iif(rule_group = 'Matching',1,0)) matching,
						sum(iif(rule_group = 'Edit',1,0)) edit,
						sum(iif(rule_group = 'KPI' and process_type = 'Last Contact',1,0)) kpi,
						sum(iif(rule_group = 'KPI' and process_type = 'Update',1,0)) kpi_update,
						count(distinct cif_no) total
						from (
						  select distinct contact_branch_code, contact_branch_name, cif_no, rule_group, process_type
						  from dqs_validate
						  where validate_status in ('complete','correct','transfer')
						  and inform_flag = 1
						  and district_code = {$d->district_code}
						  {$branch_string}
						  union
						  select distinct contact_branch_code, contact_branch_name, cif_no, rule_group, 'Initial' process_type
						  from dqs_initial_validate
						  where validate_status in ('complete','correct','transfer')
						  and inform_flag = 1
						  and district_code = {$d->district_code}
						  {$branch_string}						  
						) a
						group by contact_branch_code, contact_branch_name	
						order by contact_branch_name asc
					";

					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}		
		$filename = "Progressed_Report_" . date('dm') .  substr(date('Y') + 543,2,2);
		$x = Excel::create($filename, function($excel) use($operations, $filename) {
			$excel->sheet($filename, function($sheet) use($operations) {
				$sheet->appendRow(array('', '', 'Cleansing', 'Mapping', 'Matching', 'Edit', 'KPI-Last Contact', 'KPI-Update', 'Total (Distinct)'));				
				foreach ($operations as $o) {
					$sheet->appendRow(array(
						$o->operation_name,
						'ผลรวม',
						$o->cleansing,
						$o->mapping,
						$o->matching,
						$o->edit,
						$o->kpi,
						$o->kpi_update,
						$o->total
					));
					foreach ($o->regions as $r) {
						$sheet->appendRow(array(
							'--' . $r->region_name,
							'ผลรวม',
							$r->cleansing,
							$r->mapping,
							$r->matching,
							$r->edit,
							$r->kpi,
							$r->kpi_update,
							$r->total
						));					
						foreach ($r->districts as $d) {
							$sheet->appendRow(array(
								'----' . $d->district_name,
								'ผลรวม',
								$d->cleansing,
								$d->mapping,
								$d->matching,
								$d->edit,
								$d->kpi,
								$d->kpi_update,
								$d->total
							));
							$sheet->appendRow(array('------รหัสสาขา', 'ชื่อสาขา'));
							foreach ($d->branches as $b) {
								$sheet->appendRow(array(
									'------' . $b->contact_branch_code,
									$b->contact_branch_name,
									$b->cleansing,
									$b->mapping,
									$b->matching,
									$b->edit,
									$b->kpi,
									$b->kpi_update,
									$b->total
								));									
							}
						}
					}
				}

			});

		})->export('xls');			
		
	}		
	
	public function customer(Request $request)
	{
		set_time_limit(0);
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		// $operations_in = array();
		// $op_query_string = '';
		// empty($request->operation_code) ?: ($op_query_string .= ' and d.operation_id = ? ' AND $operations_in[] = $request->operation_code);
		// empty($request->region_code) ?: ($op_query_string .= ' and b.region = ? ' AND $operations_in[] = $request->region_code);	
		// empty($request->district_code) ?: ($op_query_string .= ' and b.dist = ? ' AND $operations_in[] = $request->district_code);	
		// if ($role->all_branch_flag == 1) {
			// empty($request->contact_branch_code) ?: ($op_query_string .= ' and a.last_contact_branch = ? ' AND $operations_in[] = $request->contact_branch_code);	
		// } else {
			
			// empty($request->contact_branch_code) ?: ($op_query_string .= ' and a.last_contact_branch = ? ' AND $operations_in[] = $request->contact_branch_code);			
		// }
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {	
			empty($request->operation_code) ?: ($op_string .= " and d.operation_id = " . $request->operation_code);			
		} else {		
			$op_string .= "
				and d.operation_id in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and d.operation_id = " . $request->operation_code);		
		}		

		$operations_query = "
			select isnull(d.operation_id,0) operation_code, d.operation_name, sum(iif(type = 0 and grade = 'A',1,0)) idv_complete,
			sum(iif(type = 0 and isnull(grade,0) != 'A',1,0)) idv_incomplete,
			sum(iif(type = 0,1,0)) total_idv,
			sum(iif(type = 1 and grade = 'A',1,0)) corp_complete,
			sum(iif(type = 1 and isnull(grade,0) != 'A',1,0)) corp_incomplete,
			sum(iif(type = 1,1,0)) total_corp,
			sum(iif(type in (0,1) and grade = 'A',1,0)) all_complete,
			sum(iif(type in (0,1) and isnull(grade,0) != 'A',1,0)) all_incomplete,
			sum(iif(type in (0,1),1,0)) total_all
			from dqs_cust a
			left outer join dqs_branch b
			on a.last_contact_branch = b.brcd
			left outer join dqs_region c
			on b.region = c.region_code
			left outer join dqs_branch_operation d
			on c.operation_id = d.operation_id
			where customer_flag = 1
			and a.acn is not null
			{$op_string}
			group by d.operation_id, d.operation_name
			order by d.operation_name asc
		";

		$operations = DB::select($operations_query);
		//return $operations;
		foreach ($operations as $o) {
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {	
				empty($request->region_code) ?: ($region_string .= " and b.region = " . $request->region_code);			
			} else {		
				$region_string .= "
					and b.region in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and b.region = " . $request->region_code);		
			}			
			
			$regions_query = "
				select isnull(b.region,0) region_code, b.regdesc region_name, sum(iif(type = 0 and grade = 'A',1,0)) idv_complete,
				sum(iif(type = 0 and isnull(grade,0) != 'A',1,0)) idv_incomplete,
				sum(iif(type = 0,1,0)) total_idv,
				sum(iif(type = 1 and grade = 'A',1,0)) corp_complete,
				sum(iif(type = 1 and isnull(grade,0) != 'A',1,0)) corp_incomplete,
				sum(iif(type = 1,1,0)) total_corp,
				sum(iif(type in (0,1) and grade = 'A',1,0)) all_complete,
				sum(iif(type in (0,1) and isnull(grade,0) != 'A',1,0)) all_incomplete,
				sum(iif(type in (0,1),1,0)) total_all
				from dqs_cust a
				left outer join dqs_branch b
				on a.last_contact_branch = b.brcd
				left outer join dqs_region c
				on b.region = c.region_code
				left outer join dqs_branch_operation d
				on c.operation_id = d.operation_id
				where customer_flag = 1
				and a.acn is not null
				and isnull(d.operation_id,0) = {$o->operation_code}
				{$region_string}
				group by b.region, b.regdesc		
				order by b.regdesc asc
			";

			$regions = DB::select($regions_query);
			foreach ($regions as $r) {
				$district_string = "";
				
				if ($role->all_branch_flag == 1) {	
					empty($request->district_code) ?: ($district_string .= " and b.dist = " . $request->district_code);			
				} else {		
					$district_string .= "
						and b.dist in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and b.dist = " . $request->district_code);		
				}		
				
				$districts_query = "
					select isnull(b.dist,0) district_code, b.distdesc district_name, sum(iif(type = 0 and grade = 'A',1,0)) idv_complete,
					sum(iif(type = 0 and isnull(grade,0) != 'A',1,0)) idv_incomplete,
					sum(iif(type = 0,1,0)) total_idv,
					sum(iif(type = 1 and grade = 'A',1,0)) corp_complete,
					sum(iif(type = 1 and isnull(grade,0) != 'A',1,0)) corp_incomplete,
					sum(iif(type = 1,1,0)) total_corp,
					sum(iif(type in (0,1) and grade = 'A',1,0)) all_complete,
					sum(iif(type in (0,1) and isnull(grade,0) != 'A',1,0)) all_incomplete,
					sum(iif(type in (0,1),1,0)) total_all
					from dqs_cust a
					left outer join dqs_branch b
					on a.last_contact_branch = b.brcd
					left outer join dqs_region c
					on b.region = c.region_code
					left outer join dqs_branch_operation d
					on c.operation_id = d.operation_id
					where customer_flag = 1
					and a.acn is not null
					and isnull(b.region,0) = {$r->region_code}
					{$district_string}
					group by b.dist, b.distdesc	
					order by b.distdesc asc
				";
			
				$districts = DB::select($districts_query);
				
				foreach ($districts as $d) {
					$branch_string = "";
					
					if ($role->all_branch_flag == 1) {	
						empty($request->contact_branch_code) ?: ($branch_string .= " and a.last_contact_branch = " . $request->contact_branch_code);			
					} else {		
						$branch_string .= "
							and a.last_contact_branch in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and a.last_contact_branch = " . $request->contact_branch_code);		
					}		
					$branches_query = "
						select isnull(a.last_contact_branch,0) contact_branch_code, b.[desc] contact_branch_name, sum(iif(type = 0 and grade = 'A',1,0)) idv_complete,
						sum(iif(type = 0 and isnull(grade,0) != 'A',1,0)) idv_incomplete,
						sum(iif(type = 0,1,0)) total_idv,
						sum(iif(type = 1 and grade = 'A',1,0)) corp_complete,
						sum(iif(type = 1 and isnull(grade,0) != 'A',1,0)) corp_incomplete,
						sum(iif(type = 1,1,0)) total_corp,
						sum(iif(type in (0,1) and grade = 'A',1,0)) all_complete,
						sum(iif(type in (0,1) and isnull(grade,0) != 'A',1,0)) all_incomplete,
						sum(iif(type in (0,1),1,0)) total_all
						from dqs_cust a
						left outer join dqs_branch b
						on a.last_contact_branch = b.brcd
						left outer join dqs_region c
						on b.region = c.region_code
						left outer join dqs_branch_operation d
						on c.operation_id = d.operation_id
						where customer_flag = 1
						and a.acn is not null
						and isnull(b.dist,0) = {$d->district_code}
						{$branch_string}
						group by a.last_contact_branch, b.[desc]
						order by b.[desc] asc
					";

					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}
		return response()->json($operations);		
	}
	
	public function customer_export(Request $request)
	{
		set_time_limit(0);
		ini_set('memory_limit', '2048M');
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {	
			empty($request->operation_code) ?: ($op_string .= " and d.operation_id = " . $request->operation_code);			
		} else {		
			$op_string .= "
				and d.operation_id in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and d.operation_id = " . $request->operation_code);		
		}		

		$operations_query = "
			select isnull(d.operation_id,0) operation_code, d.operation_name, sum(iif(type = 0 and grade = 'A',1,0)) idv_complete,
			sum(iif(type = 0 and isnull(grade,0) != 'A',1,0)) idv_incomplete,
			sum(iif(type = 0,1,0)) total_idv,
			sum(iif(type = 1 and grade = 'A',1,0)) corp_complete,
			sum(iif(type = 1 and isnull(grade,0) != 'A',1,0)) corp_incomplete,
			sum(iif(type = 1,1,0)) total_corp,
			sum(iif(type in (0,1) and grade = 'A',1,0)) all_complete,
			sum(iif(type in (0,1) and isnull(grade,0) != 'A',1,0)) all_incomplete,
			sum(iif(type in (0,1),1,0)) total_all
			from dqs_cust a
			left outer join dqs_branch b
			on a.last_contact_branch = b.brcd
			left outer join dqs_region c
			on b.region = c.region_code
			left outer join dqs_branch_operation d
			on c.operation_id = d.operation_id
			where customer_flag = 1
			and a.acn is not null
			{$op_string}
			group by d.operation_id, d.operation_name
			order by d.operation_name asc
		";

		$operations = DB::select($operations_query);
		//return $operations;
		foreach ($operations as $o) {
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {	
				empty($request->region_code) ?: ($region_string .= " and b.region = " . $request->region_code);			
			} else {		
				$region_string .= "
					and b.region in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and b.region = " . $request->region_code);		
			}			
			
			$regions_query = "
				select isnull(b.region,0) region_code, b.regdesc region_name, sum(iif(type = 0 and grade = 'A',1,0)) idv_complete,
				sum(iif(type = 0 and isnull(grade,0) != 'A',1,0)) idv_incomplete,
				sum(iif(type = 0,1,0)) total_idv,
				sum(iif(type = 1 and grade = 'A',1,0)) corp_complete,
				sum(iif(type = 1 and isnull(grade,0) != 'A',1,0)) corp_incomplete,
				sum(iif(type = 1,1,0)) total_corp,
				sum(iif(type in (0,1) and grade = 'A',1,0)) all_complete,
				sum(iif(type in (0,1) and isnull(grade,0) != 'A',1,0)) all_incomplete,
				sum(iif(type in (0,1),1,0)) total_all
				from dqs_cust a
				left outer join dqs_branch b
				on a.last_contact_branch = b.brcd
				left outer join dqs_region c
				on b.region = c.region_code
				left outer join dqs_branch_operation d
				on c.operation_id = d.operation_id
				where customer_flag = 1
				and a.acn is not null
				and isnull(d.operation_id,0) = {$o->operation_code}
				{$region_string}
				group by b.region, b.regdesc		
				order by b.regdesc asc
			";

			$regions = DB::select($regions_query);
			foreach ($regions as $r) {
				$district_string = "";
				
				if ($role->all_branch_flag == 1) {	
					empty($request->district_code) ?: ($district_string .= " and b.dist = " . $request->district_code);			
				} else {		
					$district_string .= "
						and b.dist in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and b.dist = " . $request->district_code);		
				}		
				
				$districts_query = "
					select isnull(b.dist,0) district_code, b.distdesc district_name, sum(iif(type = 0 and grade = 'A',1,0)) idv_complete,
					sum(iif(type = 0 and isnull(grade,0) != 'A',1,0)) idv_incomplete,
					sum(iif(type = 0,1,0)) total_idv,
					sum(iif(type = 1 and grade = 'A',1,0)) corp_complete,
					sum(iif(type = 1 and isnull(grade,0) != 'A',1,0)) corp_incomplete,
					sum(iif(type = 1,1,0)) total_corp,
					sum(iif(type in (0,1) and grade = 'A',1,0)) all_complete,
					sum(iif(type in (0,1) and isnull(grade,0) != 'A',1,0)) all_incomplete,
					sum(iif(type in (0,1),1,0)) total_all
					from dqs_cust a
					left outer join dqs_branch b
					on a.last_contact_branch = b.brcd
					left outer join dqs_region c
					on b.region = c.region_code
					left outer join dqs_branch_operation d
					on c.operation_id = d.operation_id
					where customer_flag = 1
					and a.acn is not null
					and isnull(b.region,0) = {$r->region_code}
					{$district_string}
					group by b.dist, b.distdesc	
					order by b.distdesc asc
				";
			
				$districts = DB::select($districts_query);
				
				foreach ($districts as $d) {
					$branch_string = "";
					
					if ($role->all_branch_flag == 1) {	
						empty($request->contact_branch_code) ?: ($branch_string .= " and a.last_contact_branch = " . $request->contact_branch_code);			
					} else {		
						$branch_string .= "
							and a.last_contact_branch in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and a.last_contact_branch = " . $request->contact_branch_code);		
					}		
					$branches_query = "
						select isnull(a.last_contact_branch,0) contact_branch_code, b.[desc] contact_branch_name, sum(iif(type = 0 and grade = 'A',1,0)) idv_complete,
						sum(iif(type = 0 and isnull(grade,0) != 'A',1,0)) idv_incomplete,
						sum(iif(type = 0,1,0)) total_idv,
						sum(iif(type = 1 and grade = 'A',1,0)) corp_complete,
						sum(iif(type = 1 and isnull(grade,0) != 'A',1,0)) corp_incomplete,
						sum(iif(type = 1,1,0)) total_corp,
						sum(iif(type in (0,1) and grade = 'A',1,0)) all_complete,
						sum(iif(type in (0,1) and isnull(grade,0) != 'A',1,0)) all_incomplete,
						sum(iif(type in (0,1),1,0)) total_all
						from dqs_cust a
						left outer join dqs_branch b
						on a.last_contact_branch = b.brcd
						left outer join dqs_region c
						on b.region = c.region_code
						left outer join dqs_branch_operation d
						on c.operation_id = d.operation_id
						where customer_flag = 1
						and a.acn is not null
						and isnull(b.dist,0) = {$d->district_code}
						{$branch_string}
						group by a.last_contact_branch, b.[desc]
						order by b.[desc] asc
					";

					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}
		
		$filename = "Customer_Report_" . date('dm') .  substr(date('Y') + 543,2,2);
		$x = Excel::create($filename, function($excel) use($operations, $filename) {
			$excel->sheet($filename, function($sheet) use($operations) {
				$sheet->appendRow(array('ประเภทลูกค้า', '', 'ลูกค้าบุคคล', '','', 'ลูกค้านิติบุคคล', '', '', 'รวม', '', ''));
				$sheet->appendRow(array('', '', 'สมบูรณ์', 'ไม่สมบูรณ์', 'ทั้งหมด', 'สมบูรณ์', 'ไม่สมบูรณ์', 'ทั้งหมด', 'สมบูรณ์', 'ไม่สมบูรณ์', 'ทั้งหมด'));		
				foreach ($operations as $o) {
					$sheet->appendRow(array(
						$o->operation_name,
						'ผลรวม',
						$o->idv_complete,
						$o->idv_incomplete,
						$o->total_idv,
						$o->corp_complete,
						$o->corp_incomplete,
						$o->total_corp,
						$o->all_complete,
						$o->all_incomplete,
						$o->total_all
					));
					foreach ($o->regions as $r) {
						$sheet->appendRow(array(
							'--' . $r->region_name,
							'ผลรวม',
							$r->idv_complete,
							$r->idv_incomplete,
							$r->total_idv,
							$r->corp_complete,
							$r->corp_incomplete,
							$r->total_corp,
							$r->all_complete,
							$r->all_incomplete,
							$r->total_all
						));					
						foreach ($r->districts as $d) {
							$sheet->appendRow(array(
								'----' . $d->district_name,
								'ผลรวม',
								$d->idv_complete,
								$d->idv_incomplete,
								$d->total_idv,
								$d->corp_complete,
								$d->corp_incomplete,
								$d->total_corp,
								$d->all_complete,
								$d->all_incomplete,
								$d->total_all
							));
							$sheet->appendRow(array('------รหัสสาขา', 'ชื่อสาขา'));
							foreach ($d->branches as $b) {
								$sheet->appendRow(array(
								'------' . $b->contact_branch_code,
								$b->contact_branch_name,
								$b->idv_complete,
								$b->idv_incomplete,
								$b->total_idv,
								$b->corp_complete,
								$b->corp_incomplete,
								$b->total_corp,
								$b->all_complete,
								$b->all_incomplete,
								$b->total_all
								));									
							}
						}
					}
				}

			});

		})->export('xls');					
	}	
	
	public function overdue_kpi(Request $request)
	{
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {	
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);			
		} else {			
			$op_string .= "
				and operation_code in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);		
		}

		$operations_query = "
			select operation_code, operation_name, 
			sum(iif(over_due between 30 and 60,1,0)) month_1,
			sum(iif(over_due between 61 and 90,1,0)) month_2,
			sum(iif(over_due between 91 and 120,1,0)) month_3,
			sum(iif(over_due between 121 and 150,1,0)) month_4,
			sum(iif(over_due between 151 and 180,1,0)) month_5,
			sum(iif(over_due between 181 and 210,1,0)) month_6,
			sum(iif(over_due between 211 and 240,1,0)) month_7,
			sum(iif(over_due between 241 and 270,1,0)) month_8,
			sum(iif(over_due between 271 and 300,1,0)) month_9,
			sum(iif(over_due between 301 and 330,1,0)) month_10,
			sum(iif(over_due between 331 and 360,1,0)) month_11,
			sum(iif(over_due between 361 and 390,1,0)) month_12,
			sum(iif(over_due > 391,1,0)) month_13,
			sum(iif(over_due > 29,1,0)) total
			from
			(
			  select distinct operation_code, operation_name, region_code, region_name, district_code, district_name, contact_branch_code, contact_branch_name, cif_no, datediff(day,rule_start_date,sysdatetime()) over_due
			  from dqs_validate
			  where inform_flag = 1
			  and rule_group = 'KPI'
			  {$op_string}
			  and validate_status in ('incomplete','wrong')
			  and process_type = 'Last Contact'
			) a
			group by operation_code, operation_name
			order by operation_name asc
		";

		$operations = DB::select($operations_query);
		//return $operations;
		foreach ($operations as $o) {
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {	
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);			
			} else {			
				$region_string .= "
					and region_code in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);		
			}
			
			$regions_query = "
				select region_code, region_name,
				sum(iif(over_due between 30 and 60,1,0)) month_1,
				sum(iif(over_due between 61 and 90,1,0)) month_2,
				sum(iif(over_due between 91 and 120,1,0)) month_3,
				sum(iif(over_due between 121 and 150,1,0)) month_4,
				sum(iif(over_due between 151 and 180,1,0)) month_5,
				sum(iif(over_due between 181 and 210,1,0)) month_6,
				sum(iif(over_due between 211 and 240,1,0)) month_7,
				sum(iif(over_due between 241 and 270,1,0)) month_8,
				sum(iif(over_due between 271 and 300,1,0)) month_9,
				sum(iif(over_due between 301 and 330,1,0)) month_10,
				sum(iif(over_due between 331 and 360,1,0)) month_11,
				sum(iif(over_due between 361 and 390,1,0)) month_12,
				sum(iif(over_due > 391,1,0)) month_13,
				sum(iif(over_due > 29,1,0)) total
				from
				(
				  select distinct operation_code, operation_name, region_code, region_name, district_code, district_name, contact_branch_code, contact_branch_name, cif_no, datediff(day,rule_start_date,sysdatetime()) over_due
				  from dqs_validate
				  where inform_flag = 1
				  and rule_group = 'KPI'
				  and operation_code = {$o->operation_code}
				  {$region_string}
				  and validate_status in ('incomplete','wrong')
				  and process_type = 'Last Contact'
				) a
				group by region_code, region_name	
				order by region_name asc
			";
			
			$regions = DB::select($regions_query);
			
			foreach ($regions as $r) {
				$district_string = "";
				
				if ($role->all_branch_flag == 1) {	
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);			
				} else {			
					$district_string .= "
						and district_code in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);		
				}
				$districts_query = "
					select district_code, district_name,
					sum(iif(over_due between 30 and 60,1,0)) month_1,
					sum(iif(over_due between 61 and 90,1,0)) month_2,
					sum(iif(over_due between 91 and 120,1,0)) month_3,
					sum(iif(over_due between 121 and 150,1,0)) month_4,
					sum(iif(over_due between 151 and 180,1,0)) month_5,
					sum(iif(over_due between 181 and 210,1,0)) month_6,
					sum(iif(over_due between 211 and 240,1,0)) month_7,
					sum(iif(over_due between 241 and 270,1,0)) month_8,
					sum(iif(over_due between 271 and 300,1,0)) month_9,
					sum(iif(over_due between 301 and 330,1,0)) month_10,
					sum(iif(over_due between 331 and 360,1,0)) month_11,
					sum(iif(over_due between 361 and 390,1,0)) month_12,
					sum(iif(over_due > 391,1,0)) month_13,
					sum(iif(over_due > 29,1,0)) total
					from
					(
					  select distinct operation_code, operation_name, region_code, region_name, district_code, district_name, contact_branch_code, contact_branch_name, cif_no, datediff(day,rule_start_date,sysdatetime()) over_due
					  from dqs_validate
					  where inform_flag = 1
					  and rule_group = 'KPI'
					  and region_code = {$r->region_code}
					  {$district_string}
					  and validate_status in ('incomplete','wrong')
					  and process_type = 'Last Contact'
					) a
					group by district_code, district_name
					order by district_name asc
				";

				$districts = DB::select($districts_query);
				foreach ($districts as $d) {
					$branch_string = "";
					
					if ($role->all_branch_flag == 1) {	
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);			
					} else {			
						$branch_string .= "
							and contact_branch_code in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);		
					}
					$branches_query = "
						select contact_branch_code, contact_branch_name,
						sum(iif(over_due between 30 and 60,1,0)) month_1,
						sum(iif(over_due between 61 and 90,1,0)) month_2,
						sum(iif(over_due between 91 and 120,1,0)) month_3,
						sum(iif(over_due between 121 and 150,1,0)) month_4,
						sum(iif(over_due between 151 and 180,1,0)) month_5,
						sum(iif(over_due between 181 and 210,1,0)) month_6,
						sum(iif(over_due between 211 and 240,1,0)) month_7,
						sum(iif(over_due between 241 and 270,1,0)) month_8,
						sum(iif(over_due between 271 and 300,1,0)) month_9,
						sum(iif(over_due between 301 and 330,1,0)) month_10,
						sum(iif(over_due between 331 and 360,1,0)) month_11,
						sum(iif(over_due between 361 and 390,1,0)) month_12,
						sum(iif(over_due > 391,1,0)) month_13,
						sum(iif(over_due > 29,1,0)) total
						from
						(
						  select distinct operation_code, operation_name, region_code, region_name, district_code, district_name, contact_branch_code, contact_branch_name, cif_no, datediff(day,rule_start_date,sysdatetime()) over_due
						  from dqs_validate
						  where inform_flag = 1
						  and rule_group = 'KPI'
						  and district_code = {$d->district_code}
						  {$branch_string}
						  and validate_status in ('incomplete','wrong')
						  and process_type = 'Last Contact'
						) a
						group by contact_branch_code, contact_branch_name
						order by contact_branch_name asc
					";

					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}
		return response()->json($operations);
	}	
	
	public function overdue_kpi_export(Request $request)
	{
		set_time_limit(0);
		ini_set('memory_limit', '2048M');
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {	
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);			
		} else {			
			$op_string .= "
				and operation_code in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);		
		}

		$operations_query = "
			select operation_code, operation_name, 
			sum(iif(over_due between 30 and 60,1,0)) month_1,
			sum(iif(over_due between 61 and 90,1,0)) month_2,
			sum(iif(over_due between 91 and 120,1,0)) month_3,
			sum(iif(over_due between 121 and 150,1,0)) month_4,
			sum(iif(over_due between 151 and 180,1,0)) month_5,
			sum(iif(over_due between 181 and 210,1,0)) month_6,
			sum(iif(over_due between 211 and 240,1,0)) month_7,
			sum(iif(over_due between 241 and 270,1,0)) month_8,
			sum(iif(over_due between 271 and 300,1,0)) month_9,
			sum(iif(over_due between 301 and 330,1,0)) month_10,
			sum(iif(over_due between 331 and 360,1,0)) month_11,
			sum(iif(over_due between 361 and 390,1,0)) month_12,
			sum(iif(over_due > 391,1,0)) month_13,
			sum(iif(over_due > 29,1,0)) total
			from
			(
			  select distinct operation_code, operation_name, region_code, region_name, district_code, district_name, contact_branch_code, contact_branch_name, cif_no, datediff(day,rule_start_date,sysdatetime()) over_due
			  from dqs_validate
			  where inform_flag = 1
			  and rule_group = 'KPI'
			  {$op_string}
			  and validate_status in ('incomplete','wrong')
			  and process_type = 'Last Contact'
			) a
			group by operation_code, operation_name
			order by operation_name asc
		";

		$operations = DB::select($operations_query);
		//return $operations;
		foreach ($operations as $o) {
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {	
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);			
			} else {			
				$region_string .= "
					and region_code in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);		
			}
			
			$regions_query = "
				select region_code, region_name,
				sum(iif(over_due between 30 and 60,1,0)) month_1,
				sum(iif(over_due between 61 and 90,1,0)) month_2,
				sum(iif(over_due between 91 and 120,1,0)) month_3,
				sum(iif(over_due between 121 and 150,1,0)) month_4,
				sum(iif(over_due between 151 and 180,1,0)) month_5,
				sum(iif(over_due between 181 and 210,1,0)) month_6,
				sum(iif(over_due between 211 and 240,1,0)) month_7,
				sum(iif(over_due between 241 and 270,1,0)) month_8,
				sum(iif(over_due between 271 and 300,1,0)) month_9,
				sum(iif(over_due between 301 and 330,1,0)) month_10,
				sum(iif(over_due between 331 and 360,1,0)) month_11,
				sum(iif(over_due between 361 and 390,1,0)) month_12,
				sum(iif(over_due > 391,1,0)) month_13,
				sum(iif(over_due > 29,1,0)) total
				from
				(
				  select distinct operation_code, operation_name, region_code, region_name, district_code, district_name, contact_branch_code, contact_branch_name, cif_no, datediff(day,rule_start_date,sysdatetime()) over_due
				  from dqs_validate
				  where inform_flag = 1
				  and rule_group = 'KPI'
				  and operation_code = {$o->operation_code}
				  {$region_string}
				  and validate_status in ('incomplete','wrong')
				  and process_type = 'Last Contact'
				) a
				group by region_code, region_name	
				order by region_name asc
			";
			
			$regions = DB::select($regions_query);
			
			foreach ($regions as $r) {
				$district_string = "";
				
				if ($role->all_branch_flag == 1) {	
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);			
				} else {			
					$district_string .= "
						and district_code in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);		
				}
				$districts_query = "
					select district_code, district_name,
					sum(iif(over_due between 30 and 60,1,0)) month_1,
					sum(iif(over_due between 61 and 90,1,0)) month_2,
					sum(iif(over_due between 91 and 120,1,0)) month_3,
					sum(iif(over_due between 121 and 150,1,0)) month_4,
					sum(iif(over_due between 151 and 180,1,0)) month_5,
					sum(iif(over_due between 181 and 210,1,0)) month_6,
					sum(iif(over_due between 211 and 240,1,0)) month_7,
					sum(iif(over_due between 241 and 270,1,0)) month_8,
					sum(iif(over_due between 271 and 300,1,0)) month_9,
					sum(iif(over_due between 301 and 330,1,0)) month_10,
					sum(iif(over_due between 331 and 360,1,0)) month_11,
					sum(iif(over_due between 361 and 390,1,0)) month_12,
					sum(iif(over_due > 391,1,0)) month_13,
					sum(iif(over_due > 29,1,0)) total
					from
					(
					  select distinct operation_code, operation_name, region_code, region_name, district_code, district_name, contact_branch_code, contact_branch_name, cif_no, datediff(day,rule_start_date,sysdatetime()) over_due
					  from dqs_validate
					  where inform_flag = 1
					  and rule_group = 'KPI'
					  and region_code = {$r->region_code}
					  {$district_string}
					  and validate_status in ('incomplete','wrong')
					  and process_type = 'Last Contact'
					) a
					group by district_code, district_name
					order by district_name asc
				";

				$districts = DB::select($districts_query);
				foreach ($districts as $d) {
					$branch_string = "";
					
					if ($role->all_branch_flag == 1) {	
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);			
					} else {			
						$branch_string .= "
							and contact_branch_code in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);		
					}
					$branches_query = "
						select contact_branch_code, contact_branch_name,
						sum(iif(over_due between 30 and 60,1,0)) month_1,
						sum(iif(over_due between 61 and 90,1,0)) month_2,
						sum(iif(over_due between 91 and 120,1,0)) month_3,
						sum(iif(over_due between 121 and 150,1,0)) month_4,
						sum(iif(over_due between 151 and 180,1,0)) month_5,
						sum(iif(over_due between 181 and 210,1,0)) month_6,
						sum(iif(over_due between 211 and 240,1,0)) month_7,
						sum(iif(over_due between 241 and 270,1,0)) month_8,
						sum(iif(over_due between 271 and 300,1,0)) month_9,
						sum(iif(over_due between 301 and 330,1,0)) month_10,
						sum(iif(over_due between 331 and 360,1,0)) month_11,
						sum(iif(over_due between 361 and 390,1,0)) month_12,
						sum(iif(over_due > 391,1,0)) month_13,
						sum(iif(over_due > 29,1,0)) total
						from
						(
						  select distinct operation_code, operation_name, region_code, region_name, district_code, district_name, contact_branch_code, contact_branch_name, cif_no, datediff(day,rule_start_date,sysdatetime()) over_due
						  from dqs_validate
						  where inform_flag = 1
						  and rule_group = 'KPI'
						  and district_code = {$d->district_code}
						  {$branch_string}
						  and validate_status in ('incomplete','wrong')
						  and process_type = 'Last Contact'
						) a
						group by contact_branch_code, contact_branch_name
						order by contact_branch_name asc
					";

					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}
		$filename = "Overdue_KPI_Report_" . date('dm') .  substr(date('Y') + 543,2,2);
		$x = Excel::create($filename, function($excel) use($operations, $filename) {
			$excel->sheet($filename, function($sheet) use($operations) {
				$sheet->appendRow(array('งวดที่ค้าง (เดือน)', '', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '>12', 'รวม'));	
				foreach ($operations as $o) {
					$sheet->appendRow(array(
						$o->operation_name,
						'ผลรวม',
						$o->month_1,
						$o->month_2,
						$o->month_3,
						$o->month_4,
						$o->month_5,
						$o->month_6,
						$o->month_7,
						$o->month_8,
						$o->month_9,
						$o->month_10,
						$o->month_11,
						$o->month_12,
						$o->month_13,
						$o->total
					));
					foreach ($o->regions as $r) {
						$sheet->appendRow(array(
							'--' . $r->region_name,
							'ผลรวม',
							$r->month_1,
							$r->month_2,
							$r->month_3,
							$r->month_4,
							$r->month_5,
							$r->month_6,
							$r->month_7,
							$r->month_8,
							$r->month_9,
							$r->month_10,
							$r->month_11,
							$r->month_12,
							$r->month_13,
							$r->total
						));					
						foreach ($r->districts as $d) {
							$sheet->appendRow(array(
								'----' . $d->district_name,
								'ผลรวม',
								$d->month_1,
								$d->month_2,
								$d->month_3,
								$d->month_4,
								$d->month_5,
								$d->month_6,
								$d->month_7,
								$d->month_8,
								$d->month_9,
								$d->month_10,
								$d->month_11,
								$d->month_12,
								$d->month_13,
								$d->total
							));
							$sheet->appendRow(array('------รหัสสาขา', 'ชื่อสาขา'));
							foreach ($d->branches as $b) {
								$sheet->appendRow(array(
								'------' . $b->contact_branch_code,
								$b->contact_branch_name,
								$b->month_1,
								$b->month_2,
								$b->month_3,
								$b->month_4,
								$b->month_5,
								$b->month_6,
								$b->month_7,
								$b->month_8,
								$b->month_9,
								$b->month_10,
								$b->month_11,
								$b->month_12,
								$b->month_13,
								$b->total
								));									
							}
						}
					}
				}

			});

		})->export('xls');			
	}		
	
	public function merge_cif(Request $request)
	{
		$query = "
			select a.merge_id, a.cif_no, b.[desc] cust_type, a.citizen_id, a.own_branch_code, c.[desc] own_branch_name, a.contact_branch_code, e.[desc] contact_branch_name, d.province_name, a.cust_name, a.cust_surname
			from dqs_merge_cif a
			left outer join dqs_cust_type b
			on a.cust_type_code = b.gsbccode
			left outer join dqs_branch c
			on a.own_branch_code = c.brcd
			left outer join dqs_province d
			on a.provice_code = d.province_code	
			left outer join dqs_branch e
			on a.contact_branch_code = e.brcd
			where 1=1
		";
		
		$query_footer = "
			order by merge_id asc
		";
		
		$qinput = array();
		
		empty($request->cust_type) ?: ($query .= " and a.cust_type_code = ? " AND $qinput[] = $request->cust_type);
		empty($request->province) ?: ($query .= " and a.provice_code = ? " AND $qinput[] = $request->province);
		empty($request->name) ?: ($query .= " and a.cust_name like ? " AND $qinput[] = '%' . $request->name . '%');
		empty($request->surname) ?: ($query .= " and a.cust_surname like ? " AND $qinput[] = '%' . $request->surname . '%');
		
		$items = DB::select($query . $query_footer, $qinput);
		// Get the current page from the url if it's not set default to 1
		empty($request->page) ? $page = 1 : $page = $request->page;
		
		// Number of items per page
		empty($request->rpp) ? $perPage = 10 : $perPage = $request->rpp;

		// Start displaying items from this number;
		$offSet = ($page * $perPage) - $perPage; // Start displaying items from this number

		// Get only the items you need using array_slice (only get 10 items since that's what you need)
		$itemsForCurrentPage = array_slice($items, $offSet, $perPage, false);
		// Return the paginator with only 10 items but with the count of all items and set the it on the correct page
		$result = new LengthAwarePaginator($itemsForCurrentPage, count($items), $perPage, $page);			

		return response()->json(['data' => $items]);	
		//return response()->json($result);	
	}
	
	public function merge_cif_export(Request $request)
	{
		set_time_limit(0);
		ini_set('memory_limit', '2048M');	
		$query = "
			select a.merge_id, a.cif_no, b.[desc] cust_type, a.citizen_id, a.own_branch_code, c.[desc] own_branch_name, a.contact_branch_code, e.[desc] contact_branch_name, d.province_name, a.cust_name, a.cust_surname
			from dqs_merge_cif a
			left outer join dqs_cust_type b
			on a.cust_type_code = b.gsbccode
			left outer join dqs_branch c
			on a.own_branch_code = c.brcd
			left outer join dqs_province d
			on a.provice_code = d.province_code	
			left outer join dqs_branch e
			on a.contact_branch_code = e.brcd
			where 1=1
		";
		$query_footer = "
			order by merge_id asc
		";		
		$qinput = array();
		
		empty($request->cust_type) ?: ($query .= " and a.cust_type_code = ? " AND $qinput[] = $request->cust_type);
		empty($request->province) ?: ($query .= " and a.provice_code = ? " AND $qinput[] = $request->province);
		empty($request->name) ?: ($query .= " and a.cust_name like ? " AND $qinput[] = '%' . $request->name . '%');
		empty($request->surname) ?: ($query .= " and a.cust_surname like ? " AND $qinput[] = '%' . $request->surname . '%');
		
		$items = DB::select($query . $query_footer, $qinput);
		
		$filename = "Merge_CIF_" . date('dm') .  substr(date('Y') + 543,2,2);
		$x = Excel::create($filename, function($excel) use($items, $filename) {
			$excel->sheet($filename, function($sheet) use($items) {
				
				$sheet->appendRow(array('Merge ID', 'CIF No.', 'Cust Type', 'ID', 'Own Branch', 'Last Contact Branch', 'Province', 'Name', 'Surname'));
		
				foreach ($items as $i) {
					$sheet->appendRow(array(
						$i->merge_id,
						$i->cif_no, 
						$i->cust_type, 
						$i->citizen_id, 
						$i->own_branch_name, 
						$i->contact_branch_name,
						$i->province_name,
						$i->cust_name,
						$i->cust_surname
						));
				}
			});

		})->export('xls');		
	}

	public function kpi_result(Request $request)
	{
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}

		$country_query = "
			select nof_person_incomplete_cif, 
			nof_nodoc_incomplete_cif, 
			nof_all_cif, 
			a.percent_complete,
			b.average_kpi
			from (
				select sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
				sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
				sum(nof_all_cif) nof_all_cif, 
				cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
				from dqs_kpi_result
				where year = {$request->year}
			    and month_no = {$request->month}
			) a
			cross join (
				select sum(percent_complete)/count(distinct month_no) average_kpi
				from (
						select year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
						from dqs_kpi_result
						where year = {$request->year}
						and month_no <= {$request->month}
						group by year, month_no
				) z
			) b
		";		
		
		$country = DB::select($country_query);
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {	
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);			
		} else {			
			$op_string .= "
				and operation_code in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);		
		}
		
		$operations_query = "
			select a.operation_code, a.operation_name, 
			nof_person_incomplete_cif, 
			nof_nodoc_incomplete_cif, 
			nof_all_cif, 
			percent_complete,
			b.average_kpi
			from 
			(
				select operation_code, operation_name, 
				sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
				sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
				sum(nof_all_cif) nof_all_cif, 
				cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
				from dqs_kpi_result
				where year = {$request->year}
			    and month_no = {$request->month}
				{$op_string}
				group by operation_code, operation_name
			) a 
			left outer join 
			(
				select operation_code, sum(percent_complete)/count(distinct month_no) average_kpi
				from (
						select operation_code, year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
						from dqs_kpi_result
						where year = {$request->year}
						and month_no <= {$request->month}
						{$op_string}
						group by operation_code, year, month_no
				) z
				group by operation_code
			) b
			on a.operation_code = b.operation_code
			order by a.operation_name asc
		";
		

		$operations = DB::select($operations_query);

		foreach ($operations as $o) {
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {	
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);			
			} else {			
				$region_string .= "
					and region_code in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);		
			}
			$regions_query = "
				select a.region_code, a.region_name, 
				nof_person_incomplete_cif, 
				nof_nodoc_incomplete_cif, 
				nof_all_cif, 
				percent_complete,
				b.average_kpi
				from 
				(
					select region_code, region_name, 
					sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
					sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
					sum(nof_all_cif) nof_all_cif, 
					cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
					from dqs_kpi_result
					where year = {$request->year}
					and month_no = {$request->month}
					and operation_code = {$o->operation_code}
					{$region_string}
					group by region_code, region_name
				) a 
				left outer join 
				(
					select region_code, sum(percent_complete)/count(distinct month_no) average_kpi
					from (
							select region_code, year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
							from dqs_kpi_result
							where year = {$request->year}
							and month_no <= {$request->month}
							{$region_string}
							group by region_code, year, month_no
					) z
					group by region_code
				) b
				on a.region_code = b.region_code
				order by a.region_name asc
			";			
			
			$regions = DB::select($regions_query);
			
			foreach ($regions as $r) {
				$district_string = "";
				
				if ($role->all_branch_flag == 1) {	
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);			
				} else {			
					$district_string .= "
						and district_code in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);		
				}
				$districts_query = "
					select a.district_code, a.district_name, 
					nof_person_incomplete_cif, 
					nof_nodoc_incomplete_cif, 
					nof_all_cif, 
					percent_complete,
					b.average_kpi
					from 
					(
						select district_code, district_name, 
						sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
						sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
						sum(nof_all_cif) nof_all_cif, 
						cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
						from dqs_kpi_result
						where year = {$request->year}
						and month_no = {$request->month}
						and region_code = {$r->region_code}
						{$district_string}
						group by district_code, district_name
					) a 
					left outer join 
					(
						select district_code, sum(percent_complete)/count(distinct month_no) average_kpi
						from (
								select district_code, year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
								from dqs_kpi_result
								where year = {$request->year}
								and month_no <= {$request->month}
								{$district_string}
								group by district_code, year, month_no
						) z
						group by district_code
					) b
					on a.district_code = b.district_code
					order by a.district_name asc
				";				
				
				$districts = DB::select($districts_query);

				foreach ($districts as $d) {
					$branch_string = "";
					
					if ($role->all_branch_flag == 1) {	
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);			
					} else {			
						$branch_string .= "
							and contact_branch_code in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);		
					}

					$branches_query = "
						select a.contact_branch_code, a.contact_branch_name, 
						nof_person_incomplete_cif, 
						nof_nodoc_incomplete_cif, 
						nof_all_cif, 
						percent_complete,
						b.average_kpi
						from 
						(
							select contact_branch_code, contact_branch_name, 
							sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
							sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
							sum(nof_all_cif) nof_all_cif, 
							cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
							from dqs_kpi_result
							where year = {$request->year}
							and month_no = {$request->month}
							and district_code = {$d->district_code}
							{$branch_string}
							group by contact_branch_code, contact_branch_name
						) a 
						left outer join 
						(
							select contact_branch_code, sum(percent_complete)/count(distinct month_no) average_kpi
							from (
									select contact_branch_code, year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
									from dqs_kpi_result
									where year = {$request->year}
									and month_no <= {$request->month}
									{$region_string}
									group by contact_branch_code, year, month_no
							) z
							group by contact_branch_code
						) b
						on a.contact_branch_code = b.contact_branch_code
						order by a.contact_branch_name asc
					";										
					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}
		return response()->json(["country" => $country, "operations" => $operations]);
	}
	
	public function kpi_result_export(Request $request)
	{
		set_time_limit(0);
		ini_set('memory_limit', '2048M');
		$user = DQSUser::find(Auth::user()->personnel_id);
		$role = DQSRole::find($user->role_id);
		if (empty($role)) {
			return response()->json(['status' => 400, 'Role not found for current user.']);
		}
		
		$country_query = "
			select nof_person_incomplete_cif, 
			nof_nodoc_incomplete_cif, 
			nof_all_cif, 
			a.percent_complete,
			b.average_kpi
			from (
				select sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
				sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
				sum(nof_all_cif) nof_all_cif, 
				cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
				from dqs_kpi_result
				where year = {$request->year}
			    and month_no = {$request->month}
			) a
			cross join (
				select sum(percent_complete)/count(distinct month_no) average_kpi
				from (
						select year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
						from dqs_kpi_result
						where year = {$request->year}
						and month_no <= {$request->month}
						group by year, month_no
				) z
			) b
		";		
		
		$country = DB::select($country_query);
		
		$op_string = "";
		
		if ($role->all_branch_flag == 1) {	
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);			
		} else {			
			$op_string .= "
				and operation_code in (
				select distinct a.operation_id
				from dqs_branch_operation a
				left outer join dqs_region b
				on a.operation_id = b.operation_id
				left outer join (
				  select distinct dist, distdesc, region, regdesc
				  from dqs_branch
				) c
				on b.region_code = c.region
				left outer join dqs_branch d
				on c.dist = d.dist
				where a.cost_center = {$user->revised_cost_center}
				or b.region_code = {$user->revised_cost_center}
				or c.dist = {$user->revised_cost_center}
				or d.ccdef = {$user->revised_cost_center})
			";
			empty($request->operation_code) ?: ($op_string .= " and operation_code = " . $request->operation_code);		
		}
		
		$operations_query = "
			select a.operation_code, a.operation_name, 
			nof_person_incomplete_cif, 
			nof_nodoc_incomplete_cif, 
			nof_all_cif, 
			percent_complete,
			b.average_kpi
			from 
			(
				select operation_code, operation_name, 
				sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
				sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
				sum(nof_all_cif) nof_all_cif, 
				cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
				from dqs_kpi_result
				where year = {$request->year}
			    and month_no = {$request->month}
				{$op_string}
				group by operation_code, operation_name
			) a 
			left outer join 
			(
				select operation_code, sum(percent_complete)/count(distinct month_no) average_kpi
				from (
						select operation_code, year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
						from dqs_kpi_result
						where year = {$request->year}
						and month_no <= {$request->month}
						{$op_string}
						group by operation_code, year, month_no
				) z
				group by operation_code
			) b
			on a.operation_code = b.operation_code
			order by a.operation_name asc
		";
		

		$operations = DB::select($operations_query);

		foreach ($operations as $o) {
			$region_string = "";
			
			if ($role->all_branch_flag == 1) {	
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);			
			} else {			
				$region_string .= "
					and region_code in (
					select distinct b.region_code
					from dqs_branch_operation a
					left outer join dqs_region b
					on a.operation_id = b.operation_id
					left outer join (
					  select distinct dist, distdesc, region, regdesc
					  from dqs_branch
					) c
					on b.region_code = c.region
					left outer join dqs_branch d
					on c.dist = d.dist
					where a.cost_center = {$user->revised_cost_center}
					or b.region_code = {$user->revised_cost_center}
					or c.dist = {$user->revised_cost_center}
					or d.ccdef = {$user->revised_cost_center})
				";
				empty($request->region_code) ?: ($region_string .= " and region_code = " . $request->region_code);		
			}
			$regions_query = "
				select a.region_code, a.region_name, 
				nof_person_incomplete_cif, 
				nof_nodoc_incomplete_cif, 
				nof_all_cif, 
				percent_complete,
				b.average_kpi
				from 
				(
					select region_code, region_name, 
					sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
					sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
					sum(nof_all_cif) nof_all_cif, 
					cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
					from dqs_kpi_result
					where year = {$request->year}
					and month_no = {$request->month}
					and operation_code = {$o->operation_code}
					{$region_string}
					group by region_code, region_name
				) a 
				left outer join 
				(
					select region_code, sum(percent_complete)/count(distinct month_no) average_kpi
					from (
							select region_code, year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
							from dqs_kpi_result
							where year = {$request->year}
							and month_no <= {$request->month}
							{$region_string}
							group by region_code, year, month_no
					) z
					group by region_code
				) b
				on a.region_code = b.region_code
				order by a.region_name asc
			";			
			
			$regions = DB::select($regions_query);
			
			foreach ($regions as $r) {
				$district_string = "";
				
				if ($role->all_branch_flag == 1) {	
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);			
				} else {			
					$district_string .= "
						and district_code in (
						select distinct c.dist
						from dqs_branch_operation a
						left outer join dqs_region b
						on a.operation_id = b.operation_id
						left outer join (
						  select distinct dist, distdesc, region, regdesc
						  from dqs_branch
						) c
						on b.region_code = c.region
						left outer join dqs_branch d
						on c.dist = d.dist
						where a.cost_center = {$user->revised_cost_center}
						or b.region_code = {$user->revised_cost_center}
						or c.dist = {$user->revised_cost_center}
						or d.ccdef = {$user->revised_cost_center})
					";
					empty($request->district_code) ?: ($district_string .= " and district_code = " . $request->district_code);		
				}
				$districts_query = "
					select a.district_code, a.district_name, 
					nof_person_incomplete_cif, 
					nof_nodoc_incomplete_cif, 
					nof_all_cif, 
					percent_complete,
					b.average_kpi
					from 
					(
						select district_code, district_name, 
						sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
						sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
						sum(nof_all_cif) nof_all_cif, 
						cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
						from dqs_kpi_result
						where year = {$request->year}
						and month_no = {$request->month}
						and region_code = {$r->region_code}
						{$district_string}
						group by district_code, district_name
					) a 
					left outer join 
					(
						select district_code, sum(percent_complete)/count(distinct month_no) average_kpi
						from (
								select district_code, year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
								from dqs_kpi_result
								where year = {$request->year}
								and month_no <= {$request->month}
								{$district_string}
								group by district_code, year, month_no
						) z
						group by district_code
					) b
					on a.district_code = b.district_code
					order by a.district_name asc
				";				
				
				$districts = DB::select($districts_query);

				foreach ($districts as $d) {
					$branch_string = "";
					
					if ($role->all_branch_flag == 1) {	
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);			
					} else {			
						$branch_string .= "
							and contact_branch_code in (
							select distinct d.brcd
							from dqs_branch_operation a
							left outer join dqs_region b
							on a.operation_id = b.operation_id
							left outer join (
							  select distinct dist, distdesc, region, regdesc
							  from dqs_branch
							) c
							on b.region_code = c.region
							left outer join dqs_branch d
							on c.dist = d.dist
							where a.cost_center = {$user->revised_cost_center}
							or b.region_code = {$user->revised_cost_center}
							or c.dist = {$user->revised_cost_center}
							or d.ccdef = {$user->revised_cost_center})
						";
						empty($request->contact_branch_code) ?: ($branch_string .= " and contact_branch_code = " . $request->contact_branch_code);		
					}

					$branches_query = "
						select a.contact_branch_code, a.contact_branch_name, 
						nof_person_incomplete_cif, 
						nof_nodoc_incomplete_cif, 
						nof_all_cif, 
						percent_complete,
						b.average_kpi
						from 
						(
							select contact_branch_code, contact_branch_name, 
							sum(nof_person_incomplete_cif) nof_person_incomplete_cif, 
							sum(nof_nodoc_incomplete_cif) nof_nodoc_incomplete_cif, 
							sum(nof_all_cif) nof_all_cif, 
							cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete			
							from dqs_kpi_result
							where year = {$request->year}
							and month_no = {$request->month}
							and district_code = {$d->district_code}
							{$branch_string}
							group by contact_branch_code, contact_branch_name
						) a 
						left outer join 
						(
							select contact_branch_code, sum(percent_complete)/count(distinct month_no) average_kpi
							from (
									select contact_branch_code, year, month_no, cast(round(cast(sum(nof_complete_cif) as numeric(15,2))/cast(sum(nof_all_cif) as numeric(15,2)) * 100, 2) as numeric(15,2)) percent_complete
									from dqs_kpi_result
									where year = {$request->year}
									and month_no <= {$request->month}
									{$region_string}
									group by contact_branch_code, year, month_no
							) z
							group by contact_branch_code
						) b
						on a.contact_branch_code = b.contact_branch_code
						order by a.contact_branch_name asc
					";										
					$branches = DB::select($branches_query);		
					$d->branches = $branches;
				}
				$r->districts = $districts;
			}
			$o->regions = $regions;
		}
		$filename = "KPI_Result_Report_" . date('dm') .  substr(date('Y') + 543,2,2);
		$x = Excel::create($filename, function($excel) use($country, $operations, $filename) {
			$excel->sheet($filename, function($sheet) use($country, $operations) {
				$sheet->appendRow(array('', '', 'ไม่สมบูรณ์(บุคคล)', 'ไม่ส่งเอกสาร(นิติบุคคล)', 'ทั้งหมด', '%ความถูกต้อง', 'KPI เฉลี่ย'));	
				$sheet->appendRow(array('ทั้งประเทศ', 'ผลรวม', $country[0]->nof_person_incomplete_cif, $country[0]->nof_nodoc_incomplete_cif, $country[0]->nof_all_cif, $country[0]->percent_complete, $country[0]->average_kpi));	
				foreach ($operations as $o) {
					$sheet->appendRow(array(
						$o->operation_name,
						'ผลรวม',
						$o->nof_person_incomplete_cif,
						$o->nof_nodoc_incomplete_cif,
						$o->nof_all_cif,
						$o->percent_complete,
						$o->average_kpi
					));
					foreach ($o->regions as $r) {
						$sheet->appendRow(array(
							'--' . $r->region_name,
							'ผลรวม',
							$r->nof_person_incomplete_cif,
							$r->nof_nodoc_incomplete_cif,
							$r->nof_all_cif,
							$r->percent_complete,
							$r->average_kpi
						));					
						foreach ($r->districts as $d) {
							$sheet->appendRow(array(
								'----' . $d->district_name,
								'ผลรวม',
								$d->nof_person_incomplete_cif,
								$d->nof_nodoc_incomplete_cif,
								$d->nof_all_cif,
								$d->percent_complete,
								$d->average_kpi
							));
							$sheet->appendRow(array('------รหัสสาขา', 'ชื่อสาขา'));
							foreach ($d->branches as $b) {
								$sheet->appendRow(array(
								'------' . $b->contact_branch_code,
								$b->contact_branch_name,
								$b->nof_person_incomplete_cif,
								$b->nof_nodoc_incomplete_cif,
								$b->nof_all_cif,
								$b->percent_complete,
								$b->average_kpi
								));									
							}
						}
					}
				}

			});

		})->export('xls');	
	}	
	
	public function duplicate_sms(Request $request) {
		$items = DB::select("
			select acn, nam
			from dqs_cust
			where aph = ?		
		", array($request->aph));
		
		return response()->json(["aph" => $request->aph, "cif" => $items]);
	}
	
}