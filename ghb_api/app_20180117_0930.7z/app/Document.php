<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
	
	const CREATED_AT = null;
	const UPDATED_AT = 'etl_dttm';
    protected $table = 'etl_rule_requitement';
	protected $primaryKey = 'id';
	public $incrementing = true;
	//public $timestamps = false;
	protected $guarded = array();
	protected $hidden = ['etl_dttm'];
}